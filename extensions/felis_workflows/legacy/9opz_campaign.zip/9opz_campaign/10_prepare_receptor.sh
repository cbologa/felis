#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"

OUT="$CAMPAIGN_ROOT/receptor/$RECEPTOR_VERSION"
if [ -e "$OUT/BUILT" ] && [ "${FORCE:-0}" != 1 ]; then
  echo "ERROR: receptor $RECEPTOR_VERSION already built at $OUT"
  echo "Use a new RECEPTOR_VERSION for changed chemistry, or FORCE=1 only for a deliberate rebuild."
  exit 2
fi
mkdir -p "$OUT"

set +u
source "$CONDA_SH"
conda activate "$FELISFF_ENV"
set -u

for x in pdb4amber tleap; do
  command -v "$x" >/dev/null || { echo "ERROR: $x missing from $FELISFF_ENV"; exit 2; }
done

read -r -a ALLOWED <<< "$REMOVE_HETATM"

echo "==> 1. Audit master and extract receptor-only heavy atoms"
python "$HERE/receptor_audit_split.py" \
  "$MASTER_PDB" "$OUT/receptor_only.pdb" \
  --report "$OUT/receptor_audit.txt" \
  --allowed-hetatm "${ALLOWED[@]}"

echo "==> 2. pdb4amber cleanup; suppress automatic S-S CONECT records"
pdb4amber -i "$OUT/receptor_only.pdb" -o "$OUT/receptor_clean.pdb" \
  --dry --nohyd --no-conect --logfile="$OUT/pdb4amber_clean.log"

echo "==> 3. Separate Reduce run for histidine tautomer suggestions"
pdb4amber -i "$OUT/receptor_only.pdb" -o "$OUT/receptor_reduce.pdb" \
  --dry --reduce --no-conect --logfile="$OUT/pdb4amber_reduce.log"

echo "==> 4. Apply HIS states and CYX names, but no explicit S-S bonds yet"
python "$HERE/receptor_finalize.py" \
  --heavy "$OUT/receptor_clean.pdb" \
  --reduce "$OUT/receptor_reduce.pdb" \
  --out "$OUT/receptor_named.pdb"

echo "==> 5. Add neutral ACE/NME caps to BOTH termini of every chain"
python "$HERE/receptor_add_caps.py" \
  "$OUT/receptor_named.pdb" "$OUT/receptor_capped.pdb" \
  --map "$OUT/residue_map.tsv" \
  --expected-chains "$EXPECTED_CHAINS"

echo "==> 6. Generate explicit S-S bonds using FINAL capped LEaP residue indices"
python "$HERE/receptor_make_disulfides.py" \
  "$OUT/receptor_capped.pdb" "$OUT/disulfides.leap" \
  --expected "$EXPECTED_DISULFIDES" \
  --expected-chains "$EXPECTED_CHAINS"

if grep -Eq '^(CONECT|SSBOND|LINK)' "$OUT/receptor_capped.pdb"; then
  echo "ERROR: connectivity records remain in receptor_capped.pdb"
  exit 3
fi

echo "==> 7. Build ff14SB receptor"
cat > "$OUT/tleap.in" <<'EOF'
source leaprc.protein.ff14SB
receptor = loadpdb receptor_capped.pdb
source disulfides.leap
check receptor
saveamberparm receptor receptor_ff14sb.prmtop receptor_ff14sb.inpcrd
savepdb receptor receptor_ff14sb.pdb
quit
EOF

(cd "$OUT" && tleap -f tleap.in | tee tleap.out)

test -s "$OUT/receptor_ff14sb.prmtop"
test -s "$OUT/receptor_ff14sb.inpcrd"

if grep -Eiq 'FATAL|does not have a type|Could not find.*parameter' "$OUT/tleap.out"; then
  echo "ERROR: LEaP reported a fatal/parameter error"
  exit 3
fi

# For this fully specified heavy-atom receptor, LEaP should not need to invent
# any new heavy atom or accept atoms outside its residue templates.
if grep -Eq 'Created a new atom named:|The file contained [1-9][0-9]* atoms not in residue templates|Added missing heavy atom:' "$OUT/tleap.out"; then
  echo "ERROR: LEaP had to invent/match unexpected heavy atoms; inspect $OUT/tleap.out"
  exit 3
fi

# With ACE/NME present LEaP must NOT create charged terminal OXT atoms.
if grep -Eq 'Added missing heavy atom:.*OXT' "$OUT/tleap.out"; then
  echo "ERROR: LEaP added OXT; at least one C terminus was not recognized as NME-capped."
  exit 3
fi

echo "==> 8. Convert to GROMACS and verify cap counts"
python - "$OUT" "$EXPECTED_CHAINS" <<'PY'
import sys, parmed as pmd
from pathlib import Path
o=Path(sys.argv[1]); nch=int(sys.argv[2])
s=pmd.load_file(str(o/"receptor_ff14sb.prmtop"),str(o/"receptor_ff14sb.inpcrd"))
names=[r.name for r in s.residues]
if names.count("ACE") != nch or names.count("NME") != nch:
    raise SystemExit(f"cap-count failure: ACE={names.count('ACE')} NME={names.count('NME')} expected={nch}")
q=sum(float(atom.charge) for atom in s.atoms)
print("atoms",len(s.atoms),"residues",len(s.residues),"net_charge",q)
print("ACE residues",names.count("ACE"),"NME residues",names.count("NME"))
s.save(str(o/"protein.top"),format="gromacs",overwrite=True)
s.save(str(o/"protein.gro"),format="gro",overwrite=True)
PY

echo "==> 9. OpenMM ingestion test"
python - "$OUT" <<'PY'
import sys
from pathlib import Path
from openmm.app import GromacsTopFile,GromacsGroFile,NoCutoff
o=Path(sys.argv[1])
top=GromacsTopFile(str(o/"protein.top"))
gro=GromacsGroFile(str(o/"protein.gro"))
system=top.createSystem(nonbondedMethod=NoCutoff,constraints=None)
assert system.getNumParticles()==len(gro.positions)
print("OpenMM GROMACS load PASS",system.getNumParticles())
PY

{
  echo "master_pdb=$MASTER_PDB"
  echo "receptor_version=$RECEPTOR_VERSION"
  echo "terminal_caps=ACE_NME_on_every_chain"
  echo "histidine_policy=Reduce; no manual HIS42 override"
  echo "expected_disulfides=$EXPECTED_DISULFIDES"
  echo "built=$(date -Is)"
  echo "felis_git=$(git -C "$FELIS_REPO" rev-parse HEAD 2>/dev/null || echo unknown)"
  sha256sum "$MASTER_PDB" "$OUT/receptor_capped.pdb" "$OUT/protein.top" "$OUT/protein.gro"
} > "$OUT/provenance.txt"

touch "$OUT/BUILT"
rm -f "$OUT/APPROVED"

echo
echo "BUILT receptor: $OUT"
echo "Review:"
echo "  cat $OUT/receptor_audit.txt"
echo "  cat $OUT/disulfides.leap"
echo "  head -20 $OUT/residue_map.tsv"
echo "  grep -E 'ACE|NME|OXT|Unit is OK|Errors =' $OUT/tleap.out"
echo
echo "Then approve:"
echo "  $HERE/11_approve_receptor.sh APPROVE"
