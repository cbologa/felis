#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"
OUT="$CAMPAIGN_ROOT/receptor/$RECEPTOR_VERSION"
test "${1:-}" = "APPROVE" || { echo "Usage: $0 APPROVE"; exit 2; }
test -e "$OUT/BUILT" || { echo "ERROR: receptor not built"; exit 2; }
test -s "$OUT/protein.top" && test -s "$OUT/protein.gro" || { echo "ERROR: receptor files missing"; exit 2; }
touch "$OUT/APPROVED"
echo "Approved receptor $RECEPTOR_VERSION at $OUT"
