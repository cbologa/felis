#!/bin/bash
set -euo pipefail
ID="${1:?Usage: $0 ligand_id}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"

ROW=$(awk -F'\t' -v id="$ID" 'NR>1 && $1==id {print; exit}' "$HERE/ligands.tsv")
test -n "$ROW" || { echo "ERROR: ligand '$ID' not in ligands.tsv"; exit 2; }
IFS=$'\t' read -r ID2 SDF CHARGE ACTIVE <<< "$ROW"
SRC="$SOURCE_DIR/$SDF"
OUT="$CAMPAIGN_ROOT/ligands/$ID"
PREFIX="$OUT/${ID}_gaff2"
mkdir -p "$OUT"

if [ -e "$OUT/PREPARED" ] && [ "${FORCE:-0}" != 1 ]; then
  echo "$ID already prepared: $OUT"
  exit 0
fi
test -s "$SRC" || { echo "ERROR: missing $SRC"; exit 2; }

set +u
source "$CONDA_SH"
conda activate "$FELISFF_ENV"
set -u

python "$FELIS_REPO/scripts/ff/felis_gaff2_ligand.py" \
  --sdf "$SRC" --charge "$CHARGE" --out-prefix "$PREFIX"

python "$FELIS_REPO/scripts/ff/validate_felis_itp.py" \
  --sdf "${PREFIX}.sdf" --itp "${PREFIX}.itp" --charge "$CHARGE"

{
  echo "ligand=$ID"
  echo "source=$SRC"
  echo "charge=$CHARGE"
  echo "prepared=$(date -Is)"
  echo "felis_git=$(git -C "$FELIS_REPO" rev-parse HEAD 2>/dev/null || echo unknown)"
  sha256sum "$SRC" "${PREFIX}.sdf" "${PREFIX}.itp"
} > "$OUT/provenance.txt"
touch "$OUT/PREPARED"
echo "PREPARED $ID -> $OUT"
