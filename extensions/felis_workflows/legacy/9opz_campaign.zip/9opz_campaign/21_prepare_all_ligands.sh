#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
while IFS=$'\t' read -r ID SDF CHARGE ACTIVE; do
  [ "$ID" = "id" ] && continue
  [ "$ACTIVE" = "1" ] || continue
  "$HERE/20_prepare_ligand.sh" "$ID"
done < "$HERE/ligands.tsv"
