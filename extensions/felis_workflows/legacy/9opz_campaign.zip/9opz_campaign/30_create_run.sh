#!/bin/bash
set -euo pipefail
ID="${1:?Usage: $0 ligand_id validation|production replica}"
MODE="${2:?Usage: $0 ligand_id validation|production replica}"
REP="${3:?Usage: $0 ligand_id validation|production replica}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"

REC="$CAMPAIGN_ROOT/receptor/$RECEPTOR_VERSION"
LIG="$CAMPAIGN_ROOT/ligands/$ID"
RUN="$CAMPAIGN_ROOT/runs/$ID/$MODE/$REP"
LIGSTEM="${ID}_gaff2"

test -e "$REC/APPROVED" || { echo "ERROR: receptor $RECEPTOR_VERSION is not APPROVED"; exit 2; }
test -e "$LIG/PREPARED" || { echo "ERROR: ligand $ID is not PREPARED"; exit 2; }
if [ -e "$RUN" ]; then echo "ERROR: run already exists: $RUN"; exit 2; fi

mkdir -p "$RUN/input"
cp "$REC/protein.gro" "$RUN/input/protein.gro"
cp "$REC/protein.top" "$RUN/input/protein.top"
cp "$LIG/${LIGSTEM}.sdf" "$RUN/input/${LIGSTEM}.sdf"
cp "$LIG/${LIGSTEM}.itp" "$RUN/input/${LIGSTEM}.itp"

case "$MODE" in
 validation) E=e05; V=v18; R=r02; N=400;;
 production) E=e29; V=v45; R=r02; N=2000;;
 *) echo "ERROR: mode must be validation or production"; exit 2;;
esac

cat > "$RUN/abfecfg.yaml" <<YAML
progro: input/protein.gro
protop: input/protein.top
sdffile: input/${LIGSTEM}.sdf
itpfile: input/${LIGSTEM}.itp
stages: ["all"]
outdir: $RUN/work
elamrecipe: $E
vlamrecipe: $V
reslamrecipe: $R
md_nsnapshots: $N
md_sol_nsnapshots: $N
md_pro_nsnapshots: $N
md_checkpoint_interval: 50
YAML

{
  echo "ligand=$ID"
  echo "mode=$MODE"
  echo "replica=$REP"
  echo "receptor_version=$RECEPTOR_VERSION"
  echo "created=$(date -Is)"
  sha256sum "$RUN/input/"*
} > "$RUN/run_provenance.txt"

echo "CREATED $RUN"
