#!/bin/bash
set -euo pipefail
MODE="${1:?Usage: $0 validation|production replica [replica...]}"
shift
[ "$#" -ge 1 ] || { echo "Need at least one replica tag"; exit 2; }
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
while IFS=$'\t' read -r ID SDF CHARGE ACTIVE; do
  [ "$ID" = "id" ] && continue
  [ "$ACTIVE" = "1" ] || continue
  for REP in "$@"; do
    "$HERE/30_create_run.sh" "$ID" "$MODE" "$REP"
  done
done < "$HERE/ligands.tsv"
