#!/bin/bash
set -euo pipefail
ID="${1:?Usage: $0 ligand_id validation|production replica}"
MODE="${2:?Usage: $0 ligand_id validation|production replica}"
REP="${3:?Usage: $0 ligand_id validation|production replica}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"
RUN="$CAMPAIGN_ROOT/runs/$ID/$MODE/$REP"
CFG="$RUN/abfecfg.yaml"
test -s "$CFG" || { echo "ERROR: missing $CFG"; exit 2; }

cd "$FELIS_REPO/scripts/slurm"
mkdir -p slurm_logs

DEP=()
if [ "${SERIAL_PREP:-1}" = 1 ]; then DEP=(--dependency=singleton); fi

JID=$(sbatch --parsable \
  --job-name=felis_prep \
  "${DEP[@]}" \
  --partition="${PREP_PARTITION}" \
  --time="${PREP_TIME}" \
  --gpus=1 \
  --export=ALL,ABFECFG="$CFG",RUNDIR="$RUN",FELIS_ENV="$FELIS_ENV",CONDA_SH="$CONDA_SH" \
  felis_prep.sbatch)

printf "prep\t%s\t%s\n" "$JID" "$(date -Is)" >> "$RUN/jobs.tsv"
echo "$ID $MODE $REP prep job: $JID"
