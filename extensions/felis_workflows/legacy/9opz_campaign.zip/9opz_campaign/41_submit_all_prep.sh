#!/bin/bash
set -euo pipefail
MODE="${1:?Usage: $0 validation|production replica}"
REP="${2:?Usage: $0 validation|production replica}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
while IFS=$'\t' read -r ID SDF CHARGE ACTIVE; do
  [ "$ID" = "id" ] && continue
  [ "$ACTIVE" = "1" ] || continue
  "$HERE/40_submit_prep.sh" "$ID" "$MODE" "$REP"
done < "$HERE/ligands.tsv"
