#!/bin/bash
set -euo pipefail
ID="${1:?Usage: $0 ligand_id validation|production replica}"
MODE="${2:?Usage: $0 ligand_id validation|production replica}"
REP="${3:?Usage: $0 ligand_id validation|production replica}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"

RUN="$CAMPAIGN_ROOT/runs/$ID/$MODE/$REP"
CFG="$RUN/abfecfg.yaml"
LIGSTEM="${ID}_gaff2"
WORKDIR="$RUN/work/$LIGSTEM"
MANIFEST="$RUN/work_units.json"

for x in makebox.done boresch_em.done boresch_npt.done boresch_post_process.done sysA_em.done sysB_em.done; do
  test -e "$WORKDIR/progress/$x" || { echo "ERROR: prep incomplete; missing $x"; exit 3; }
done

case "$MODE" in
 validation)
   NA="${NA:-6}"; NB="${NB:-8}"; TIME="${ABFE_TIME:-04:00:00}";;
 production)
   NA="${NA:-25}"; NB="${NB:-30}"
   : "${ABFE_TIME:?For production set ABFE_TIME from the 9OPZ validation benchmark}"
   TIME="$ABFE_TIME";;
 *) echo "ERROR: mode must be validation or production"; exit 2;;
esac

cd "$FELIS_REPO/scripts/slurm"
OUT="$RUN/launch_$(date +%Y%m%d_%H%M%S).log"

FELIS_REPO="$FELIS_REPO" \
ABFECFG="$CFG" \
SDF_ABS="$RUN/input/${LIGSTEM}.sdf" \
WORKDIR="$WORKDIR" \
MANIFEST="$MANIFEST" \
NA="$NA" NB="$NB" \
PARTITION="$ABFE_PARTITION" TIME="$TIME" NP_VALUE="$NP_VALUE" \
FELIS_ENV="$FELIS_ENV" CONDA_SH="$CONDA_SH" \
./submit.sh | tee "$OUT"

A=$(awk '/sysA array job id:/ {print $NF}' "$OUT" | tail -1)
B=$(awk '/sysB array job id:/ {print $NF}' "$OUT" | tail -1)
F=$(awk '/finalize job id:/ {print $NF}' "$OUT" | tail -1)
printf "sysA\t%s\t%s\nsysB\t%s\t%s\nfinalize\t%s\t%s\n" \
  "$A" "$(date -Is)" "$B" "$(date -Is)" "$F" "$(date -Is)" >> "$RUN/jobs.tsv"
echo "Recorded jobs in $RUN/jobs.tsv"
