#!/bin/bash
set -euo pipefail
ID="${1:?Usage: $0 ligand_id validation|production replica}"
MODE="${2:?Usage: $0 ligand_id validation|production replica}"
REP="${3:?Usage: $0 ligand_id validation|production replica}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/campaign.env"
RUN="$CAMPAIGN_ROOT/runs/$ID/$MODE/$REP"
WORK="$RUN/work/${ID}_gaff2"

echo "===== $ID $MODE $REP ====="
if [ -f "$RUN/jobs.tsv" ]; then
  cat "$RUN/jobs.tsv"
  IDS=$(awk '{print $2}' "$RUN/jobs.tsv" | paste -sd, -)
  echo
  sacct -j "$IDS" --format=JobID,JobName%30,Partition,State,ExitCode,Elapsed,NodeList 2>/dev/null || true
fi
echo
echo "progress:"
ls -lh "$WORK/progress" 2>/dev/null || true
echo
if [ -s "$WORK/analysis/sys_abfe.tsv" ]; then
  cat "$WORK/analysis/sys_abfe.tsv"
else
  echo "No final sys_abfe.tsv yet."
fi
