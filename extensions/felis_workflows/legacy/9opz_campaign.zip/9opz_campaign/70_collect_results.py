#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, math, statistics
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument("campaign_root",type=Path)
ap.add_argument("mode",choices=["validation","production"])
a=ap.parse_args()

rows=[]
runs=a.campaign_root/"runs"
for f in runs.glob(f"*/{a.mode}/*/work/*/analysis/sys_abfe.tsv"):
    parts=f.parts
    i=parts.index("runs")
    ligand=parts[i+1]; rep=parts[i+3]
    with f.open() as fh:
        r=next(csv.DictReader(fh,delimiter="\t"))
    rows.append({
        "ligand":ligand,"replica":rep,
        "sol":float(r["sol"]),"pro":float(r["pro"]),"res":float(r["res"]),
        "dG(kcal/mol)":float(r["dG(kcal/mol)"]),
        "path":str(f)
    })
rows.sort(key=lambda r:(r["ligand"],r["replica"]))
outdir=a.campaign_root/"results"; outdir.mkdir(exist_ok=True)
raw=outdir/f"{a.mode}_replicates.tsv"
fields_raw=["ligand","replica","sol","pro","res","dG(kcal/mol)","path"]
with raw.open("w",newline="") as fh:
    w=csv.DictWriter(fh,fieldnames=fields_raw,delimiter="\t")
    w.writeheader(); w.writerows(rows)

groups={}
for r in rows: groups.setdefault(r["ligand"],[]).append(r)
summary=outdir/f"{a.mode}_summary.tsv"
fields=["ligand","n","mean_dG","sd_dG","sem_dG","mean_sol","mean_pro","mean_res"]
with summary.open("w",newline="") as fh:
    w=csv.DictWriter(fh,fieldnames=fields,delimiter="\t"); w.writeheader()
    for lig,rs in sorted(groups.items()):
        d=[x["dG(kcal/mol)"] for x in rs]; n=len(d)
        sd=statistics.stdev(d) if n>1 else float("nan")
        w.writerow({
            "ligand":lig,"n":n,
            "mean_dG":statistics.mean(d),
            "sd_dG":sd,
            "sem_dG":sd/math.sqrt(n) if n>1 else float("nan"),
            "mean_sol":statistics.mean(x["sol"] for x in rs),
            "mean_pro":statistics.mean(x["pro"] for x in rs),
            "mean_res":statistics.mean(x["res"] for x in rs),
        })
print("wrote",raw)
print("wrote",summary)
if rows: print(summary.read_text(),end="")
