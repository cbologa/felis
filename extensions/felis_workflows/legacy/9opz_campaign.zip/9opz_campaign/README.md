# 9OPZ FELIS/GAFF2 campaign workflow — receptor v2.1

This version implements the receptor decisions made after inspecting v1:

* Both protein chains are capped with **ACE at the N terminus and NME at the C terminus**.
* For the installed AmberTools version, NME heavy atoms are named **N and C** (not N and CH3).
* HIS42 receives **no manual override**; its side chain is not oriented toward sucralose, so the Reduce-derived tautomer is retained.
* The 16 disulfides are defined exactly once, after caps are added, using the final LEaP residue indices.
* v1 remains an uncapped test build; v2 is the first capped campaign receptor.

## Install/update

Copy this directory to:

    /users/cbologa/kit/felis/scripts/9opz_campaign

Then:

    cd /users/cbologa/kit/felis/scripts/9opz_campaign
    chmod +x *.sh *.py

`campaign.env` sets `RECEPTOR_VERSION=v2`.

## Build capped receptor

    ./10_prepare_receptor.sh

Expected high-level result:

* 2 ACE residues
* 2 NME residues
* 16 explicit disulfides
* no OXT automatically added by LEaP
* LEaP Errors = 0
* OpenMM GROMACS ingestion PASS

Review:

    REC=/easley/scratch/users/cbologa/felis/9opz_campaign/receptor/v2

    cat "$REC/receptor_audit.txt"
    cat "$REC/disulfides.leap"
    head -30 "$REC/residue_map.tsv"
    grep -E 'ACE|NME|OXT|Unit is OK|Errors =' "$REC/tleap.out"
    cat "$REC/provenance.txt"

If correct:

    ./11_approve_receptor.sh APPROVE

## Prepare sucralose

    ./20_prepare_ligand.sh sucralose_p1

## Create and run one validation

    ./30_create_run.sh sucralose_p1 validation v1
    ./40_submit_prep.sh sucralose_p1 validation v1
    ./60_status.sh sucralose_p1 validation v1

After prep is complete:

    ./50_launch_abfe.sh sucralose_p1 validation v1

Validation defaults:
    e05 / v18 / r02
    400 snapshots
    NA=6 NB=8
    NP_VALUE=4

Use the 9OPZ validation timing, especially sysB, to choose `ABFE_TIME` for production.

## Production

Example:

    for R in r1 r2 r3 r4 r5; do
      ./30_create_run.sh sucralose_p1 production "$R"
      ./40_submit_prep.sh sucralose_p1 production "$R"
    done

Prep is serialized with Slurm singleton by default.

After prep is complete:

    export ABFE_TIME=<walltime_from_9OPZ_validation>

    for R in r1 r2 r3 r4 r5; do
      ./50_launch_abfe.sh sucralose_p1 production "$R"
    done

## Many ligands

`ligands.tsv` is the campaign manifest. Add one row for each new pose.

Prepare all active ligands:

    ./21_prepare_all_ligands.sh

Create r1 for all active ligands:

    ./31_create_runs_all.sh production r1

Submit all r1 prep jobs:

    ./41_submit_all_prep.sh production r1

Collect finished production results:

    python ./70_collect_results.py \
      /easley/scratch/users/cbologa/felis/9opz_campaign production

## Reproducibility rules

Never overwrite an approved receptor version.  A receptor change means v3, v4, ...
A new ligand pose gets a new ligand ID.  A new ABFE replicate gets a new run directory.
Do not copy trj/, progress/, or analysis/ between replicas.

## v2.1 correction

The first capped build exposed an AmberTools template-name mismatch.  This
AmberTools installation expects NME heavy atoms `N` and `C`.  If `CH3` is
provided, LEaP creates it as an untyped extra atom and separately adds the
template atom `C`.  v2.1 writes `N`/`C` and also treats any LEaP message about
invented/unmatched heavy atoms as a build failure.
