#!/usr/bin/env python3
from __future__ import annotations
import argparse, math
from collections import Counter, defaultdict
from pathlib import Path

STANDARD = {"ALA","ARG","ASN","ASP","CYS","GLN","GLU","GLY","HIS","HID","HIE","HIP",
            "ILE","LEU","LYS","MET","PHE","PRO","SER","THR","TRP","TYR","VAL","CYX",
            "ASH","GLH","LYN"}

def is_h(line):
    element = line[76:78].strip().upper() if len(line) >= 78 else ""
    atom = line[12:16].strip().upper().lstrip("0123456789")
    return element == "H" if element else atom.startswith("H")

def xyz(x):
    return tuple(float(x[s:e]) for s,e in ((30,38),(38,46),(46,54)))

def distance(a,b):
    return math.sqrt(sum((u-v)**2 for u,v in zip(a,b)))

def rkey(x):
    return x[21:22], x[22:26], x[26:27], x[17:20].strip()

def rlabel(k):
    return f"{k[0] or '-'}:{k[3]}{k[1].strip()}{k[2].strip()}"

ap=argparse.ArgumentParser()
ap.add_argument("pdb",type=Path)
ap.add_argument("out",type=Path)
ap.add_argument("--report",type=Path,required=True)
ap.add_argument("--allowed-hetatm",nargs="*",default=[])
a=ap.parse_args()

lines=a.pdb.read_text().splitlines(True)
if sum(x.startswith("MODEL") for x in lines) > 1:
    raise SystemExit("ERROR: multiple MODEL records; select one model first.")

atoms=[x for x in lines if x.startswith("ATOM  ")]
hets=[x for x in lines if x.startswith("HETATM")]
if not atoms:
    raise SystemExit("ERROR: no ATOM records")

het_names=sorted({x[17:20].strip() for x in hets})
unexpected=sorted(set(het_names)-set(a.allowed_hetatm))
if unexpected:
    raise SystemExit("ERROR: unexpected HETATM residue names: "+", ".join(unexpected))

order=[]; seen=set(); by=defaultdict(list)
for x in atoms:
    k=rkey(x)
    if k[:3] not in seen:
        seen.add(k[:3]); order.append(k)
    by[k[:3]].append(x)

nonstd=sorted({k[3] for k in order if k[3] not in STANDARD})
if nonstd:
    raise SystemExit("ERROR: non-standard ATOM residue names: "+", ".join(nonstd))

chains=Counter(k[0] for k in order)

cys=[]
for k in order:
    if k[3] in {"CYS","CYX"}:
        sg=next((xyz(x) for x in by[k[:3]] if x[12:16].strip()=="SG"),None)
        if sg is not None:
            cys.append((k,sg))
pairs=[]
for i in range(len(cys)):
    for j in range(i+1,len(cys)):
        dd=distance(cys[i][1],cys[j][1])
        if dd <= 3.0:
            pairs.append((dd,cys[i][0],cys[j][0]))
pairs.sort()

report=[
    f"INPUT={a.pdb}",
    f"ATOM_records={len(atoms)}",
    f"HETATM_records={len(hets)}",
    "HETATM_names="+(" ".join(het_names) if het_names else "none"),
    "chains="+", ".join(f"{k or '-'}:{v}" for k,v in sorted(chains.items())),
    f"protein_residues={len(order)}",
    "",
    "Cys SG-SG pairs <=3.0 A:"
]
report += [f"  {rlabel(k1):18s} {rlabel(k2):18s} {dd:.3f} A" for dd,k1,k2 in pairs] or ["  none"]
report += ["","Histidines:"]
report += [f"  {rlabel(k)}" for k in order if k[3] in {"HIS","HID","HIE","HIP"}] or ["  none"]

a.report.write_text("\n".join(report)+"\n")

# Receptor-only, heavy-atom PDB. Preserve original residue numbering here;
# pdb4amber will produce its own renumbering map in the next stage.
out=[]; last_chain=None
for x in atoms:
    if is_h(x):
        continue
    ch=x[21:22]
    if last_chain is not None and ch != last_chain:
        out.append("TER\n")
    out.append(x)
    last_chain=ch
out += ["TER\n","END\n"]
a.out.write_text("".join(out))

print(a.report.read_text(),end="")
print("WROTE",a.out)
