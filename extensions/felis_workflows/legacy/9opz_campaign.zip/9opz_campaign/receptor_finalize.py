#!/usr/bin/env python3
"""
Apply Reduce-derived histidine names and CYX names to the heavy-atom receptor.

Disulfide *bonds* are NOT written here.  They are generated only after terminal
caps are inserted, because ACE/NME residues change LEaP's sequential residue
indices.
"""
from __future__ import annotations
import argparse, math
from collections import defaultdict
from pathlib import Path

def k3(x): return x[21:22],x[22:26],x[26:27]
def rn(x): return x[17:20].strip()
def an(x): return x[12:16].strip()
def xyz(x): return tuple(float(x[s:e]) for s,e in ((30,38),(38,46),(46,54)))
def dist(a,b): return math.sqrt(sum((u-v)**2 for u,v in zip(a,b)))
def setrn(x,n): return x[:17]+f"{n:>3s}"+x[20:]

def parse(p):
    lines=p.read_text().splitlines(True)
    order=[]; seen=set(); by=defaultdict(list)
    for x in lines:
        if not x.startswith("ATOM  "):
            continue
        k=k3(x)
        if k not in seen:
            seen.add(k); order.append(k)
        by[k].append(x)
    return lines,order,by

ap=argparse.ArgumentParser()
ap.add_argument("--heavy",required=True,type=Path)
ap.add_argument("--reduce",required=True,type=Path)
ap.add_argument("--out",required=True,type=Path)
ap.add_argument("--disulfide-cutoff",type=float,default=2.5)
a=ap.parse_args()

hl,ho,ha=parse(a.heavy)
_,ro,ra=parse(a.reduce)
if len(ho)!=len(ro):
    raise SystemExit(f"ERROR: heavy/reduce residue count mismatch {len(ho)} vs {len(ro)}")

# Reduce-based HIS tautomer assignment.  No manual override is applied to HIS42;
# it is not oriented toward the orthosteric ligand in this receptor model.
his={}
for hk,rk in zip(ho,ro):
    if rn(ha[hk][0]) not in {"HIS","HID","HIE","HIP"}:
        continue
    rr=rn(ra[rk][0])
    names={an(x) for x in ra[rk]}
    if rr in {"HID","HIE","HIP"}:
        state=rr
    elif "HD1" in names and "HE2" in names:
        state="HIP"
    elif "HD1" in names:
        state="HID"
    elif "HE2" in names:
        state="HIE"
    else:
        state="HIE"
    his[hk]=state
    print("HIS",hk,"->",state)

# Detect the unambiguous short SG--SG pairs and rename both partners CYX.
cys=[]
for k in ho:
    if rn(ha[k][0]) in {"CYS","CYX"}:
        sg=next((xyz(x) for x in ha[k] if an(x)=="SG"),None)
        if sg is not None:
            cys.append((k,sg))
cand=[]
for i in range(len(cys)):
    for j in range(i+1,len(cys)):
        dd=dist(cys[i][1],cys[j][1])
        if dd <= a.disulfide_cutoff:
            cand.append((dd,cys[i][0],cys[j][0]))
cand.sort()

used=set(); pairs=[]
for dd,k1,k2 in cand:
    if k1 in used or k2 in used:
        continue
    used.update((k1,k2))
    pairs.append((dd,k1,k2))
    print("CYX pair",k1,k2,f"{dd:.3f} A")

out=[]
for x in hl:
    if x.startswith(("CONECT","SSBOND","LINK")):
        continue
    if x.startswith("ATOM  "):
        k=k3(x)
        if k in used and rn(x) in {"CYS","CYX"}:
            x=setrn(x,"CYX")
        elif k in his and rn(x) in {"HIS","HID","HIE","HIP"}:
            x=setrn(x,his[k])
    out.append(x)
a.out.write_text("".join(out))
print("WROTE",a.out)
