#!/usr/bin/env python3
"""
Generate explicit LEaP disulfide bond commands from the FINAL capped PDB.
This ensures LEaP residue indices include ACE/NME caps correctly.
"""
from __future__ import annotations
import argparse, math
from collections import defaultdict
from pathlib import Path

def xyz(x): return tuple(float(x[s:e]) for s,e in ((30,38),(38,46),(46,54)))
def dist(a,b): return math.sqrt(sum((u-v)**2 for u,v in zip(a,b)))
def k(x): return x[21:22],x[22:26],x[26:27],x[17:20].strip()
def an(x): return x[12:16].strip()

ap=argparse.ArgumentParser()
ap.add_argument("pdb",type=Path)
ap.add_argument("out",type=Path)
ap.add_argument("--cutoff",type=float,default=2.5)
ap.add_argument("--expected",type=int,default=None)
ap.add_argument("--expected-chains",type=int,default=None)
a=ap.parse_args()

lines=a.pdb.read_text().splitlines(True)
order=[]; seen=set(); by=defaultdict(list)
for x in lines:
    if not x.startswith("ATOM  "): continue
    kk=k(x)
    if kk[:3] not in seen:
        seen.add(kk[:3]); order.append(kk)
    by[kk[:3]].append(x)

# Validate cap placement by chain.
chains=[]
for kk in order:
    if not chains or chains[-1][0] != kk[0]:
        chains.append([kk[0],[]])
    chains[-1][1].append(kk)
if a.expected_chains is not None and len(chains)!=a.expected_chains:
    raise SystemExit(f"ERROR: found {len(chains)} chains, expected {a.expected_chains}")
for ch,rs in chains:
    if rs[0][3]!="ACE" or rs[-1][3]!="NME":
        raise SystemExit(f"ERROR: chain {ch} is not ACE...NME capped")

idx={kk[:3]:i+1 for i,kk in enumerate(order)}
cys=[]
for kk in order:
    if kk[3]!="CYX": continue
    sg=next((xyz(x) for x in by[kk[:3]] if an(x)=="SG"),None)
    if sg is None: raise SystemExit(f"ERROR: CYX lacks SG: {kk}")
    cys.append((kk,sg))

pairs=[]
used=set()
for i in range(len(cys)):
    for j in range(i+1,len(cys)):
        dd=dist(cys[i][1],cys[j][1])
        if dd<=a.cutoff:
            pairs.append((dd,cys[i][0],cys[j][0]))
pairs.sort()

chosen=[]
for dd,k1,k2 in pairs:
    if k1[:3] in used or k2[:3] in used: continue
    used.update((k1[:3],k2[:3]))
    chosen.append((dd,k1,k2))

if a.expected is not None and len(chosen)!=a.expected:
    raise SystemExit(f"ERROR: found {len(chosen)} disulfides, expected {a.expected}")
if len(used)!=len(cys):
    raise SystemExit(f"ERROR: not every CYX is paired: CYX={len(cys)}, paired={len(used)}")

out=["# Explicit disulfides for the FINAL ACE/NME-capped receptor.\n"]
for dd,k1,k2 in chosen:
    i1=idx[k1[:3]]; i2=idx[k2[:3]]
    out.append(f"bond receptor.{i1}.SG receptor.{i2}.SG\n")
    print(f"bond receptor.{i1}.SG receptor.{i2}.SG  # {k1[0]}:{k1[1].strip()} "
          f"{k2[0]}:{k2[1].strip()} {dd:.3f} A")
a.out.write_text("".join(out))
print("WROTE",a.out)
