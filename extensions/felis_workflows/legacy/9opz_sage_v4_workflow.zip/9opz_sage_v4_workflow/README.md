This package creates a fresh FELIS absolute binding free energy calculation for sucralose using OpenFF Sage 2.3.0 and its native AshGC charge model. It uses the validated receptor and bound ligand pose from your existing Easley GAFF2 production run. Parameterization preserves the explicit-hydrogen SDF atom order, stereochemistry and coordinates, and produces the SDF/ITP pair that FELIS already accepts.

The default source is:

```text
/easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1/production/p1
```

The new run is:

```text
/easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1_sage230/production/p1
```

The existing GAFF2 jobs and files are independent of this directory. Initialization refuses to overwrite an existing destination.


Put `9opz_sage_v1.zip` in `/users/cbologa/kit/felis/scripts`, then run:

```bash
cd /users/cbologa/kit/felis/scripts
unzip 9opz_sage_v1.zip
cd 9opz_sage_v1
sha256sum -c SHA256SUMS
conda activate felis
bash setup_environment.sh
```

The setup script creates a separate environment named `felis_sage_params`. It does not install OpenFF into, or update, `felis`. Sage/AshGC parameterization uses CPU PyTorch and RDKit; an OpenEye license is unnecessary. Conda package downloads require internet access during installation. The Sage XML is bundled, and the charge-model package is included in the environment specification.

The installed `felis` environment must retain its working OpenMM/CUDA, MPI, GROMACS, RDKit and FELIS/ByteMol dependencies. Production imports the existing repository at `/users/cbologa/kit/felis`. No new FELIS checkout is installed.

`environment.sage.yml` pins the core OpenFF versions and allows Conda to resolve platform-compatible dependencies. `environment-linux-64.explicit.txt` additionally records every exact package build used in local testing. To reproduce those Linux x86_64 builds, use this command *instead of* the setup script:

```bash
conda create -n felis_sage_params --file environment-linux-64.explicit.txt
```


From `/users/cbologa/kit/felis/scripts/9opz_sage_v1`, with `felis` active:

```bash
python workflow.py init
python workflow.py parameterize
```

`init` reads the real `p1/abfecfg.yaml` and `p1/work_units.json`. It copies the protein GRO and the protein TOP with its include dependencies, and takes the ligand SDF named in that config. The attached older GAFF2 YAML examples contain TYK2 paths; this workflow deliberately derives the 9OPZ configuration from the working Easley run.

The new run contains `abfecfg.yaml`, `abfecfg.prep.yaml`, `work_units.json`, `workflow.json`, frozen inputs and a private copy of the workflow scripts. Parameterization writes:

```text
parameters/sucralose_p1_sage230.sdf
parameters/sucralose_p1_sage230.itp
parameters/parameters.json
parameters/validation.json
parameters/native_system.xml
parameters/interchange.top
```

`parameters.json` records the charges, source-file checksums, force-field/model identity and package versions. The SDF is copied byte-for-byte. Parameterization rejects missing hydrogens, undefined stereochemistry, non-neutral or incomplete sucralose, and an existing parameter output directory.

Before accepting the ITP, the code checks native OpenFF versus exported OpenMM charges, Lennard-Jones terms, bonded terms, exclusions and 1–4 interactions. It compares energies and forces at three coordinate sets, and checks the expected 19 hydrogen-bond constraints. There is no fallback to GAFF2 charges or conventional AM1-BCC.


```bash
python workflow.py submit-prep --partition l40s
python workflow.py status
```

Preparation requests one GPU, 8 CPUs, 64 GB and 6 hours. FELIS builds fresh solvent and complex boxes, performs its normal preparation stages, selects/refines Boresch restraints and computes the analytic restraint correction. Both solvated topologies must pass OpenMM ligand-parameter checks and GROMACS `grompp` without bypassing warnings. The successful preparation writes `prepared.ok.json` and freezes the prepared files.

The GPU preparation and production wrappers use Slurm's allocated GPU UUID and a private MPS directory. Open MPI/PRTE temporary and shared-memory backing files use Easley's job-local `SLURM_TMPDIR` when available and otherwise the node-local `/tmp`, never the GPFS run directory. `felis_stage.py` adapts only the legacy FELIS launcher within that process; the repository and the scientific stage implementations remain as installed. The normal Boresch preparation stage retains its own four-replica/four-process command. `--np` controls the later alchemical groups.

Check the preparation log in the new run's `slurm_logs/`. Continue when it reports:

```text
Sage preparation and A/B ligand parameter validation PASS.
```

The full-system checks run on Easley because the actual receptor files and GPU runtime are there. See `VALIDATION.md` for the local checks already completed.


After preparation succeeds:

```bash
python workflow.py submit-abfe --partition l40s --time 24:00:00 --concurrency 2
python workflow.py status
```

This submits the solvent array, the complex array, and a CPU finalizer with an `afterok` dependency on both arrays. The default analysis partition is `general`; change it with `--analysis-partition` if your account uses another CPU partition.

Each array task requests one GPU, 8 CPUs and 64 GB. `--concurrency 2` applies to each leg, allowing up to four GPUs total across the two arrays. Use `--concurrency 1` to allow at most two total. Slurm schedules these alongside other submitted jobs. The wrapper passes the run and environment paths as explicit job arguments, avoiding the missing-MANIFEST export problem encountered on Hopper.

The lambda values, group memberships, reporting/checkpoint settings and iteration targets are copied from the source manifest. For the documented production baseline, this is 25 solvent groups covering 73 states and 30 complex groups covering 80 states, with 2000 iterations × 2500 steps × 2 fs = 10 ns per state. The code uses the actual manifest, validates its coverage and command consistency, and refuses incompatible paths or an unexpected reporting interval.

Completion requires each trajectory to reach its recorded iteration target with the expected replica-state assignment. Having an `.nc` file or a `.create_done` marker is insufficient. Only after this check does the finalizer write the A/B completion markers required by FELIS and run its MBAR and summary stages.

Results are under:

```text
/easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1_sage230/production/p1/work/sucralose_p1_sage230/analysis
```

The principal outputs are `A_fe_table.tsv`, `B_fe_table.tsv`, `R_fe_table.tsv` and `sys_abfe.tsv`. Keep the complete analysis directory, `prepare/sys_boresch_cfg.json`, `parameters/parameters.json`, and the `provenance/` reports for comparison with GAFF2.


| Component | Treatment |
|---|---|
| Protein construct | Uses the source protein GRO/TOP: existing capped receptor, both subunits and CRDs |
| Protein chemistry | Retains the source protonation, caps, disulfides and protein force field |
| Ligand pose | Preserves the source explicit-H SDF; normal FELIS preparation follows |
| Ligand parameters | Fresh Sage 2.3.0 valence/LJ parameters and AshGC charges |
| Water, box construction, PME and MD controls | Uses the installed FELIS builder/runtime and copied source settings |
| Restraints | Fresh geometry/anchor selection and analytic correction, with copied force constants |
| Solvent and complex sampling | Fresh trajectories for both legs; copied lambda protocol and run lengths |

Sage 2.3.0's standard charge model is AshGC, implemented through NAGL, and is trained to reproduce AM1-BCC charges. This is a comparison of the complete Sage model against GAFF2, including the charge assignment. It is not a bonded-parameter-only substitution.

The bundled *unconstrained* Sage XML retains the complete ligand bond terms. FELIS then applies its usual hydrogen-bond constraints during MD. The AMBER-compatible Lorentz–Berthelot mixing and 1–4 factors are checked explicitly. FELIS's established production nonbonded protocol is retained, rather than replacing its PME/cutoff/switching settings with the defaults an OpenFF exporter might choose for a standalone simulation. The precise installed FELIS source hashes are recorded for this reason.

This workflow reproduces the source run's preparation duration and production duration. It does not incorporate the three ongoing 50 ns GAFF2 equilibration trajectories or establish that 10 ns is converged. After those finish, an equilibrated starting structure can be selected for a separate paired comparison. A positive or negative Sage result should be assessed with overlap, time convergence and independent repeats; changing force field does not ensure the experimental affinity will be reproduced.

Do not substitute just the Sage complex leg into a GAFF2 result. Compare the complete new thermodynamic cycle, including its own solvent leg and restraint correction. The earlier connected-restraint control remains a separate GAFF2 diagnostic.


After a wall-time interruption or another diagnosed/repaired transient failure, let the previous arrays stop, then run:

```bash
python workflow.py submit-abfe --resume --partition l40s --time 24:00:00 --concurrency 2
```

This reads trajectories only after earlier array jobs have left the queue, submits incomplete groups, and lets FELIS resume from its own checkpoints. It replaces this run's pending old finalizer with one depending on the new arrays. It refuses to cancel or inspect running array jobs, to resume a trajectory with a different stored target, or to overwrite corrupt/inconsistent storage silently. Completed groups receive no new GPU allocation.

For a diagnosed node-specific failure, add `--exclude NODE` to `submit-abfe --resume`. The exclusion is applied to both replacement GPU arrays and their finalizer.

If only final analysis failed after both arrays completed, inspect its error log and resubmit just that step:

```bash
python workflow.py submit-finalize --partition general
```

For a failed preparation job, inspect `slurm_logs/` and `provenance/grompp_A.log` or `grompp_B.log`, then resubmit `submit-prep` after addressing the cause. FELIS uses its genuine stage markers to skip completed preparation stages. Do not create completion markers manually.

You can run the copied workflow directly from the run directory; it infers that run automatically:

```bash
cd /easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1_sage230/production/p1
python workflow/workflow.py status
```

`init --help` documents overrides for the source run, new run, repository, Conda activation script, environment names, MPI ranks and topology include search paths. Choose all scientific options before initialization; the files are frozen with checksums. Use a new run directory to change them. A missing topology include can be resolved by passing its parent force-field directory using `--include-dir` during initialization.

For a short pipeline validation calculation, create a separate run with `init --snapshots 200 --run /absolute/new/validation/path`, then pass that same `--run` to subsequent commands. This retains the full lambda ladder and requests 1 ns per state; it is a pipeline check, not a converged affinity estimate. The default production run inherits its duration from the source. A longer uniform production run can likewise be requested at initialization; for example, `--snapshots 4000` gives 20 ns per state at the checked timestep/reporting interval.

The Slurm templates target Easley. This package has not been configured for Hopper's modules, partitions or filesystem layout.

References and third-party attribution are in `SOURCES.md`. Local validation details and reproduction commands are in `VALIDATION.md`.
