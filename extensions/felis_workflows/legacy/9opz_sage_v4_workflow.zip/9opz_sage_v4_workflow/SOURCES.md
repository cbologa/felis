This workflow was prepared for the existing 9OPZ/sucralose FELIS campaign, using the user-provided GAFF2 generator and validator as the SDF/ITP interface reference, and the recovered campaign and Slurm scripts as the execution reference. The actual source configuration and manifest are read on Easley and archived with each new run. No GAFF2 or ByteFF ligand parameters are used by the new Sage simulation.

OpenFF Sage 2.3.0 is the stable force-field version selected for this package as of 2026-09-15. Its native charge handler is NAGL/AshGC. The force field is pinned; this workflow does not resolve an unversioned "latest" force field during a run.

- [OpenFF force-field releases and Sage charge-model information](https://github.com/openforcefield/openff-forcefields)
- [Exact bundled unconstrained Sage 2.3.0 OFFXML](https://github.com/openforcefield/openff-forcefields/blob/2026.01.0/openforcefields/offxml/openff_unconstrained-2.3.0.offxml)
- [OpenFF Toolkit installation](https://docs.openforcefield.org/projects/toolkit/en/stable/installation.html)
- [NAGL installation](https://docs.openforcefield.org/projects/nagl/en/stable/installation.html)
- [Interchange output/export documentation](https://docs.openforcefield.org/projects/interchange/en/stable/using/output.html)
- [FELIS source revision inspected for stage and launcher interfaces](https://github.com/ByteDance-Seed/felis/tree/4d2556bfe09753ff63ddf549c3838a517f173b12)
- [Slurm sbatch documentation](https://slurm.schedmd.com/sbatch.html)
- [Sucralose, PubChem CID 71485](https://pubchem.ncbi.nlm.nih.gov/compound/Sucralose)

The XML file is distributed unchanged from the Open Force Field Initiative's `openff-forcefields` repository, tag `2026.01.0`. Its SHA-256 is:

```text
65b926cf38ae4bc2f6f9cac907c3cadba154cc84988dd10ab2c3895aaf2dd995
```

The XML declares model `openff-gnn-am1bcc-1.0.0.pt`, SHA-256:

```text
7981e7f5b0b1e424c9e10a40d9e7606d96dcd3dd2b095cb4eeff6829f92238ee
```

The OpenFF NAGL loader verifies the model hash when loading it. The model itself is installed by the pinned NAGL-models package, rather than redistributed in this ZIP.

The bundled OFFXML is attributed to the Open Force Field Initiative/Open Forcefield Group and is provided under Creative Commons Attribution 4.0 International; the complete upstream notice is in `LICENSE-openff-forcefields`. That notice applies to the third-party force-field data. The additional Python and shell workflow code is newly prepared for this task. The runtime adapter calls the user's installed FELIS code; this package does not redistribute the FELIS repository.

The test SDF is a generated three-dimensional conformer derived from the public PubChem sucralose record. It is used only for software validation. The production ligand identity and coordinates come from the user's existing source SDF.
