Validation completed locally on 2026-09-15: **12 tests passed**, including actual Sage/AshGC parameterization and actual GROMACS topology preprocessing. The test run used a public sucralose conformer; it did not use the user's receptor or bound coordinates.

The 42-atom test molecule was prepared from PubChem CID 71485 with explicit hydrogens, RDKit embedding (seed 20260915) and MMFF minimization. This fixture is distributed only under `tests/`; the workflow never selects it as a simulation input. Real runs take their SDF exclusively from the source FELIS run and preserve its bytes. The generated test conformer does not represent a validated receptor binding pose.

| Check | Result |
|---|---|
| Native OpenFF Sage 2.3.0/AshGC parameterization | Passed with RDKit, NAGL and CPU PyTorch |
| Atom count, indexed connectivity and unchanged source SDF | 42 atoms, 43 bonds; passed |
| Exported valence terms | 80 angles and 195 periodic torsion terms; matched native |
| Nonbonded particles and internal exceptions | All 42 particles and 238 exclusions/1–4 exceptions matched |
| Hydrogen constraints | 19, applied through OpenMM HBonds |
| Largest energy difference, three coordinate sets | 1.64 × 10⁻⁹ kJ/mol or less |
| Largest force-component difference | 2.08 × 10⁻⁷ kJ/mol/nm or less |
| OpenMM handoff without OpenFF | Passed in a second Python environment |
| Ligand insertion/renaming and atom-index offsets | Passed in synthetic solvent and complex topologies |
| GROMACS 2026.3 preprocessing of both synthetic systems | Passed without `-maxwarn` |
| Wrong charge, reordered same-element atoms, unsupported topology physics | Rejected |
| Fresh-run setup, rebased paths and frozen-file checks | Passed |
| Missing lambda coverage and inconsistent actual command indices | Rejected |
| Three-frame trajectory versus a 2000-iteration target | Correctly rejected as incomplete using a reporter mock |
| Slurm dependency and explicit argument construction | Passed using submission mocks |
| Resume only incomplete groups; refuse active arrays | Passed using queue/submission mocks |
| Managed preparation launcher and allocated GPU UUID | Passed with a launcher contract test |

Energy and force comparisons used the OpenMM Reference platform, no periodic box and NoCutoff, so the native and exported ligand Hamiltonians were compared under the same settings. The additional coordinate sets use small Cartesian perturbations and are numerical export checks, not additional MD samples. The enforced tolerances in the production parameter validator are 0.002 kJ/mol and 0.02 kJ/mol/nm.

The independent export validation environment used Python 3.12, OpenMM 8.4 and RDKit, with no OpenFF dependency. This demonstrates that the exported files can be consumed without OpenFF; it does not establish compatibility with every older OpenMM release.

Actual tested parameterization versions/builds are recorded in `validation/package_versions.json` and fully specified in `environment-linux-64.explicit.txt`. Core versions were Toolkit 0.18.0, Interchange 0.4.11, NAGL 0.5.5, NAGL models 2025.9.0, forcefields 2026.01.0 and OpenMM 8.4.0. The Python metadata for some Conda OpenFF packages uses placeholder versions; the Conda package records are retained to avoid ambiguity.

Reproduce the local scientific tests from the unpacked package:

```bash
conda activate felis_sage_params
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 python -m pytest -q tests
```

To include the GROMACS checks, point to a working GROMACS executable:

```bash
SAGE_TEST_GMX=/absolute/path/to/gmx OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 python -m pytest -q tests
```

The GROMACS tests use a small synthetic water/protein-placeholder system to exercise insertion and renaming. The complete 9OPZ receptor, actual FELIS/ByteMol system assembly, GPU dynamics, MPS daemon execution and Slurm scheduling could not be run locally. They remain cluster checks. The provided preparation job automatically validates the actual ligand again inside `felis`, checks its parameters after full A/B system assembly, and runs GROMACS preprocessing before allowing the production arrays.

The trajectory-completion and Slurm tests exercise control logic with mocks; they are not simulations or measurements of GPU performance. No claim of ABFE convergence, receptor equilibration or improved experimental agreement follows from these software checks. Assess those from the new sampling and analysis.
