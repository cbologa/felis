#!/usr/bin/env python3
"""Create seeded ABFE replicas that share one immutable prepared Sage system."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

import yaml


STEM = "sucralose_p1_sage230"
EXPECTED_WORKFLOW = "57aa7ab8501c3de6e4bc5722afdf737dd27bf8c411814d659e3e62647ebf1fec"
EXPECTED_STAGE = "63e78dcadb479338fc721340e6c936b577f332efad43e14a783b2e06664f05ca"
PREP_FLAGS = (
    "makebox.done",
    "boresch_em.done",
    "boresch_npt.done",
    "boresch_post_process.done",
    "sysA_em.done",
    "sysB_em.done",
)
ROOT_FILES = (
    "abfecfg.yaml",
    "abfecfg.prep.yaml",
    "work_units.json",
    "workflow.json",
    "prepared.ok.json",
    "input_hashes.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def replace_strings(value, old: str, new: str):
    if isinstance(value, str):
        return value.replace(old, new)
    if isinstance(value, list):
        return [replace_strings(item, old, new) for item in value]
    if isinstance(value, dict):
        return {key: replace_strings(item, old, new) for key, item in value.items()}
    return value


def seed_token(argv: list[str]) -> tuple[int | None, int | None]:
    prefix = "i:integrator.randomseed:"
    positions = [index for index, token in enumerate(argv) if token.startswith(prefix)]
    if len(positions) > 1:
        raise ValueError(f"Multiple random-seed tokens: {positions}")
    if not positions:
        return None, None
    index = positions[0]
    return index, int(argv[index][len(prefix):])


def deterministic_seed(label: str, leg: str, index: int, used: set[int]) -> int:
    payload = f"9opz-sage230:{label}:{leg}:{index}".encode()
    candidate = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big") % 2147483646 + 1
    while candidate in used:
        candidate = candidate % 2147483646 + 1
    used.add(candidate)
    return candidate


def verify_hash_map(root: Path, mapping: dict[str, str]) -> None:
    for relative, expected in mapping.items():
        path = root / relative
        if not path.is_file():
            raise FileNotFoundError(path)
        observed = sha256(path)
        if observed != expected:
            raise ValueError(f"Hash mismatch: {path}: {observed} != {expected}")


def create_replica(source: Path, destination: Path, label: str, used_seeds: set[int]) -> None:
    temporary = destination.with_name(f".{destination.name}.creating.{os.getpid()}")
    if destination.exists() or temporary.exists():
        raise FileExistsError(f"Destination or temporary path already exists: {destination}, {temporary}")

    temporary.mkdir(parents=False)
    try:
        shutil.copytree(source / "workflow", temporary / "workflow")
        for name in ROOT_FILES:
            shutil.copy2(source / name, temporary / name)

        # These large, immutable inputs are deliberately shared.  All new output
        # (trajectories, progress markers, logs and analysis) remains replica-local.
        os.symlink(source / "input", temporary / "input", target_is_directory=True)
        os.symlink(source / "parameters", temporary / "parameters", target_is_directory=True)

        work = temporary / "work" / STEM
        work.mkdir(parents=True)
        os.symlink(source / "work" / STEM / "prepare", work / "prepare", target_is_directory=True)
        for directory in (work / "trj", work / "analysis", work / "progress",
                          temporary / "slurm_logs", temporary / "provenance"):
            directory.mkdir()
        for flag in PREP_FLAGS:
            shutil.copy2(source / "work" / STEM / "progress" / flag,
                         work / "progress" / flag)

        old_root = str(source)
        new_root = str(destination)

        for name in ("abfecfg.yaml", "abfecfg.prep.yaml"):
            path = temporary / name
            config = replace_strings(yaml.safe_load(path.read_text()), old_root, new_root)
            path.write_text(yaml.safe_dump(config, sort_keys=False))

        control_path = temporary / "workflow.json"
        control = replace_strings(json.loads(control_path.read_text()), old_root, new_root)
        control["run"] = new_root
        control["workdir"] = str(destination / "work" / STEM)
        write_json(control_path, control)

        manifest_path = temporary / "work_units.json"
        manifest = replace_strings(json.loads(manifest_path.read_text()), old_root, new_root)
        manifest["workdir"] = str(destination / "work" / STEM)
        recorded_seeds = {}
        for leg in "AB":
            for unit in manifest["units"][leg]:
                argv = unit["argv"]
                position, _old_seed = seed_token(argv)
                new_seed = deterministic_seed(label, leg, int(unit["idx"]), used_seeds)
                token = f"i:integrator.randomseed:{new_seed}"
                if position is None:
                    try:
                        position = argv.index("--rextkv")
                    except ValueError as error:
                        raise ValueError(f"{leg}{unit['idx']}: no --rextkv token") from error
                    argv.insert(position, token)
                else:
                    argv[position] = token
                recorded_seeds[f"{leg}{unit['idx']}"] = new_seed
        write_json(manifest_path, manifest)

        # Recalculate the frozen-input hashes for the few run-local files changed
        # above.  Shared prepared files retain and must pass their original hashes.
        input_hash_path = temporary / "input_hashes.json"
        input_hashes = json.loads(input_hash_path.read_text())
        for relative in input_hashes:
            input_hashes[relative] = sha256(temporary / relative)
        write_json(input_hash_path, input_hashes)

        prepared = json.loads((temporary / "prepared.ok.json").read_text())
        verify_hash_map(temporary, input_hashes)
        verify_hash_map(temporary, prepared["hashes"])

        for path in (temporary / "workflow.json", temporary / "work_units.json",
                     temporary / "abfecfg.yaml", temporary / "abfecfg.prep.yaml"):
            if old_root in path.read_text():
                raise ValueError(f"Old run path remains in {path}")

        all_new = []
        for leg in "AB":
            for unit in manifest["units"][leg]:
                position, value = seed_token(unit["argv"])
                if position is None or value is None:
                    raise ValueError(f"Missing seed after rewrite: {leg}{unit['idx']}")
                all_new.append(value)
        if len(all_new) != len(set(all_new)):
            raise ValueError("New random seeds are not unique")

        provenance = {
            "replica": label,
            "prepared_system_source": old_root,
            "shared_read_only_paths": ["input", "parameters", f"work/{STEM}/prepare"],
            "workflow_sha256": sha256(temporary / "workflow" / "workflow.py"),
            "stage_sha256": sha256(temporary / "workflow" / "stage.sbatch"),
            "random_seeds": recorded_seeds,
        }
        write_json(temporary / "provenance" / "replica_clone.json", provenance)
        temporary.rename(destination)
        print(f"Created {destination} with {len(all_new)} independent group seeds")
    except BaseException:
        print(f"Incomplete clone retained for diagnosis: {temporary}", file=sys.stderr)
        raise


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: clone_sage_replicas.py SOURCE_P1 DEST_P2 DEST_P3")
    source = Path(sys.argv[1]).resolve()
    destinations = [(Path(sys.argv[2]).resolve(), "p2"), (Path(sys.argv[3]).resolve(), "p3")]
    if any(destination.exists() for destination, _label in destinations):
        raise FileExistsError("p2 and/or p3 already exists; nothing was changed")

    required = [source / name for name in ROOT_FILES]
    required += [source / "workflow" / "workflow.py", source / "workflow" / "stage.sbatch",
                 source / "provenance" / "completion_audit.json",
                 source / "work" / STEM / "analysis" / "sys_abfe.tsv"]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(path)
    if sha256(source / "workflow" / "workflow.py") != EXPECTED_WORKFLOW:
        raise ValueError("Unexpected source workflow.py")
    if sha256(source / "workflow" / "stage.sbatch") != EXPECTED_STAGE:
        raise ValueError("Unexpected source stage.sbatch")

    audit = json.loads((source / "provenance" / "completion_audit.json").read_text())
    if len(audit) != 55 or not all(record.get("complete") is True for record in audit):
        raise ValueError("Source p1 does not have 55 audited complete groups")

    source_manifest = json.loads((source / "work_units.json").read_text())
    used_seeds: set[int] = set()
    for leg in "AB":
        for unit in source_manifest["units"][leg]:
            _position, value = seed_token(unit["argv"])
            if value is not None:
                used_seeds.add(value)

    for destination, label in destinations:
        create_replica(source, destination, label, used_seeds)

    print("Replica cloning PASS")


if __name__ == "__main__":
    main()
