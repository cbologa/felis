#!/usr/bin/env python3
"""Run normal FELIS stages using the enclosing Slurm job's GPU/MPS allocation.

The installed FELIS source is never edited. Its legacy launcher creates global
/tmp/mps_<gpu> directories and unsets CUDA_VISIBLE_DEVICES; this process-local
adapter delegates MPS lifetime to stage.sbatch and keeps its GPU UUID filter.
All dynamics, topology construction, restraint and analysis stage code remains
FELIS code, with the original stage arguments.
"""
import os
import runpy


def install_adapter(job_context, utils, cuda_tools):
    original = job_context._run_one_subprocess

    def subprocess_in_allocation(self, args, working_dir, extra_envs=None):
        if args == 'echo quit | nvidia-cuda-mps-control' or args == ['nvidia-cuda-mps-control', '-d']:
            # stage.sbatch owns the daemon, including for successive prep stages.
            return 0
        return original(self, args, working_dir, extra_envs)

    def mpi_in_allocation(cls, common_cmd, gpu_id, np):
        if os.environ.get('SAGE_MPS_MANAGED') != '1' or not os.environ.get('CUDA_VISIBLE_DEVICES', '').startswith('GPU-'):
            raise ValueError('FELIS GPU stages must run through stage.sbatch with allocated-GPU MPS')
        command = ['mpirun', '--oversubscribe', '--bind-to', 'none', '-np', str(np), '-x', f'NP_VALUE={np}']
        for name in ['PATH', 'PYTHONPATH', 'CUDA_VISIBLE_DEVICES', 'CUDA_MPS_PIPE_DIRECTORY', 'CUDA_MPS_LOG_DIRECTORY']:
            if name in os.environ:
                command += ['-x', name]
        return command + list(common_cmd)

    def visible_devices():
        # One UUID-selected GPU has logical index 0 in this process;
        # the launcher above preserves the UUID instead of exporting this index.
        return ['0'] if os.environ.get('CUDA_VISIBLE_DEVICES', '').startswith('GPU-') else []

    job_context._run_one_subprocess = subprocess_in_allocation
    job_context.build_cuda_mps_mpirun_command = classmethod(mpi_in_allocation)
    utils.get_visible_cuda_devices = visible_devices
    cuda_tools.get_visible_cuda_devices = visible_devices


def main():
    import felis.utils
    import felis.utils.cuda_tools
    from felis.protocols.abfe.job_context import JobContext
    install_adapter(JobContext, felis.utils, felis.utils.cuda_tools)
    runpy.run_module('felis.app.abfe', run_name='__main__')


if __name__ == '__main__':
    main()
