#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
SAGE_ENV=${SAGE_ENV:-felis_sage_params}
command -v conda >/dev/null || { echo 'Activate your Conda shell first.' >&2; exit 1; }
# Create is deliberate: do not update the active FELIS environment.
conda env create --name "$SAGE_ENV" --file "$SCRIPT_DIR/environment.sage.yml"
conda run --no-capture-output -n "$SAGE_ENV" python -c \
  'from openff.toolkit import ForceField; from openff.toolkit.utils.nagl_wrapper import NAGLToolkitWrapper; print(NAGLToolkitWrapper()); print(ForceField("openff_unconstrained-2.3.0.offxml", load_plugins=True))'
