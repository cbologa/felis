"""Scientific round trip and safeguards against GAFF2 reuse/false completion."""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import sys
import types
from unittest.mock import patch
import numpy as np
import pytest
import yaml

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
from sage_common import STEM, DEFAULTS, make_itp, sha256, rows, verify_hashes
from felis_sage_ligand import parameterize
from validate_sage import validate
import workflow as wf

@pytest.fixture(scope='session')
def params(tmp_path_factory):
    out=tmp_path_factory.mktemp('native')/'parameters'
    parameterize(PACKAGE/'tests/sucralose_test_3d.sdf',out)
    return out

def manifest(work):
    out={'workdir':str(work),'na':1,'nb':2,'sysA_lam':[[1,1,0],[0,1,0],[0,0,0]],
         'sysB_lam':[[0,0,1],[1,0,1],[1,1,1],[1,1,0]],'units':{'A':[],'B':[]}}
    for leg,groups in [('A',[[0,1,2]]),('B',[[0,1,2],[2,3]])]:
        for idx,ids in enumerate(groups):
            stem=f'{leg.lower()}{idx}'
            argv=['python3','-m','felis.app.dyn.repex','--cfg',f'prepare/sys{leg}_lam.json',
                  f'prepare/sys{leg}_ab_ligatoms.json']
            if leg=='B':argv+=['prepare/sys_boresch_cfg.json']
            argv+=['--tkv',f's:filename.stem:{stem}','s:filename.monomer:/old/input/sucralose_p1_gaff2.sdf',
                   f's:filename.sys:prepare/sys{leg}.top',f's:filename.crd:prepare/sys{leg}_em.pdb',
                   f's:filename.atom_ids:prepare/sys{leg}_atom_ids.json','s:dir.trj:trj',
                   'i:openmm.checkpoint_interval:50','i:integrator.npt:1',
                   'i:integrator.nstep_per_snapshot:2500','i:integrator.nsnapshots:2000',
                   '--rextkv',*[f'i:ab.ilam:{i}' for i in ids]]
            out['units'][leg].append({'idx':idx,'stem':stem,'ilam':ids,'argv':argv})
    return out

def test_native_roundtrip_and_no_pose_change(params):
    result=validate(params)
    assert result['passed'] and result['particles']==42 and result['hydrogen_constraints']==19
    assert sha256(params/f'{STEM}.sdf')==sha256(PACKAGE/'tests/sucralose_test_3d.sdf')
    meta=json.loads((params/'parameters.json').read_text())
    assert abs(meta['net_charge_e'])<1e-8 and meta['charge_model']=='openff-gnn-am1bcc-1.0.0.pt'
    assert max(x['energy_difference_kJ_mol'] for x in result['energy_force_checks'])<1e-5

def test_corrupted_charge_rejected_even_without_hash_check(params,tmp_path):
    target=tmp_path/'bad';shutil.copytree(params,target)
    path=target/f'{STEM}.itp';text=path.read_text();current=None;out=[];changed=False
    for line in text.splitlines():
        if line.strip().startswith('['):current=line.strip('[] ')
        if current=='atoms' and line.split() and line.split()[0]=='1' and not changed:
            fields=line.split();fields[6]=str(float(fields[6])+.1);line=' '.join(fields);changed=True
        out.append(line)
    assert changed;path.write_text('\n'.join(out)+'\n')
    with pytest.raises(ValueError,match='charges|parameters'):
        validate(target,check_hashes=False)

def test_same_element_atom_swap_rejected(params,tmp_path):
    target=tmp_path/'swapped';shutil.copytree(params,target)
    from rdkit import Chem
    p=target/f'{STEM}.sdf';m=Chem.SDMolSupplier(str(p),removeHs=False)[0]
    carbon=[a.GetIdx() for a in m.GetAtoms() if a.GetAtomicNum()==6]
    order=list(range(42));i,j=carbon[:2];order[i],order[j]=order[j],order[i]
    m=Chem.RenumberAtoms(m,order);w=Chem.SDWriter(str(p));w.write(m);w.close()
    with pytest.raises(ValueError,match='bond graphs'):
        validate(target,check_hashes=False)

def test_export_never_drops_unsupported_physics(params):
    top=(params/'interchange.top').read_text()
    with pytest.raises(ValueError,match='Unsupported sections'):
        make_itp(top+'\n[ virtual_sites2 ]\n1 2 3 1 0.5\n')
    wrong=top.replace('0.500000','0.800000',1)
    assert wrong!=top
    with pytest.raises(ValueError,match='Incompatible nonbonded'):
        make_itp(wrong)

def test_fresh_setup_preserves_protocol_and_rebases_inputs(tmp_path,params):
    source=tmp_path/'gaff2';(source/'input').mkdir(parents=True)
    (source/'input/protein.gro').write_text('protein coordinates\n')
    (source/'input/types.itp').write_text('[ atomtypes ]\nX 6 12.01 0 A 0.3 0.1\n')
    (source/'input/protein.top').write_text('[ defaults ]\n'+DEFAULTS+'\n#include "types.itp"\n')
    shutil.copyfile(params/f'{STEM}.sdf',source/'input/lig.sdf')
    (source/'input/lig.itp').write_text('original GAFF2\n')
    cfg={'progro':'input/protein.gro','protop':'input/protein.top','sdffile':'input/lig.sdf',
         'itpfile':'input/lig.itp','outdir':'work','elamrecipe':'e29','vlamrecipe':'v45',
         'md_pro_nsnapshots':2000,'md_sol_nsnapshots':2000,'md_eq_nsnapshots':600,
         'k_r_a_dih':[2.,80.,80.],'pro_ionic_strength':0.0}
    (source/'abfecfg.yaml').write_text(yaml.safe_dump(cfg))
    base=manifest(source/'work/lig');(source/'work_units.json').write_text(json.dumps(base))
    (source/'work/lig/progress').mkdir(parents=True);(source/'work/lig/progress/mbar.done').touch()
    root=tmp_path/'sage';repo=tmp_path/'repo';repo.mkdir()
    a=argparse.Namespace(source_run=source,run=root,felis_repo=repo,felis_env='felis',sage_env='felis_sage_params',
                         conda_sh=tmp_path/'conda.sh',np=4,snapshots=None,include_dir=[])
    wf.initialize(a);control,new=wf.read_run(root)
    newcfg=yaml.safe_load((root/'abfecfg.yaml').read_text())
    for k in ['elamrecipe','vlamrecipe','md_eq_nsnapshots','k_r_a_dih','pro_ionic_strength']:
        assert newcfg[k]==cfg[k]
    assert not (root/f'work/{STEM}/progress').exists()
    assert new['sysB_lam']==base['sysB_lam']
    assert (root/'input/protein.gro').read_bytes()==(source/'input/protein.gro').read_bytes()
    for leg in 'AB':
        for u in new['units'][leg]:assert 'gaff2' not in '\n'.join(u['argv'])
    include=re_include=(root/'input/protein.top').read_text().split('#include "')[1].split('"')[0]
    assert Path(include).is_file() and Path(include).is_relative_to(root)
    (root/'input/protein.gro').write_text('modified')
    with pytest.raises(ValueError,match='Input changed'):wf.read_run(root)

def test_missing_lambda_edge_and_external_gaff2_path_rejected(tmp_path):
    base=manifest(tmp_path/'old')
    bad=copy.deepcopy(base);bad['units']['B'][1]['ilam']=[1,3]
    bad['units']['B'][1]['argv'][-2:]=['i:ab.ilam:1','i:ab.ilam:3']
    with pytest.raises(ValueError,match='adjacent lambda'):wf.clone_manifest(bad,tmp_path/'old',tmp_path/'new',tmp_path/'new.sdf')
    bad=copy.deepcopy(base);argv=bad['units']['A'][0]['argv'];i=argv.index('s:filename.sys:prepare/sysA.top')
    argv[i]='s:filename.sys:/unexpected/gaff2/sysA.top'
    with pytest.raises(ValueError,match='External simulation input'):
        wf.clone_manifest(bad,tmp_path/'old',tmp_path/'new',tmp_path/'new.sdf')
    bad=copy.deepcopy(base);bad['units']['A'][0]['argv'][-1]='i:ab.ilam:1'
    with pytest.raises(ValueError,match='lambda indices differ'):
        wf.clone_manifest(bad,tmp_path/'old',tmp_path/'new',tmp_path/'new.sdf')

def test_cancelled_three_frame_run_is_not_complete(tmp_path,monkeypatch):
    m=wf.clone_manifest(manifest(tmp_path),tmp_path,tmp_path,tmp_path/'sage.sdf');u=m['units']['B'][0]
    (tmp_path/'trj').mkdir();(tmp_path/'trj/b0.nc').touch()
    class Reporter:
        last=2;target=2000
        def __init__(self,*a,**k):assert k['open_mode']=='r'
        def read_last_iteration(self,last_checkpoint=True):return 0 if last_checkpoint else self.last
        def read_dict(self,key):return {'number_of_iterations':self.target}
        def read_replica_thermodynamic_states(self,iteration):return np.arange(3)
        def close(self):pass
    monkeypatch.setitem(sys.modules,'openmmtools',types.ModuleType('openmmtools'))
    module=types.ModuleType('openmmtools.multistate');module.MultiStateReporter=Reporter
    monkeypatch.setitem(sys.modules,'openmmtools.multistate',module)
    assert not wf.iteration_status(m,'B',u)['complete']
    Reporter.last=2000;assert wf.iteration_status(m,'B',u)['complete']
    Reporter.target=2;assert not wf.iteration_status(m,'B',u)['complete']

def test_slurm_dependency_and_absolute_arguments(tmp_path,monkeypatch):
    root=tmp_path/'run';root.mkdir();(root/'workflow').mkdir()
    c={'felis_env':'felis','conda_sh':'/users/cbologa/miniconda3/etc/profile.d/conda.sh',
       'felis_repo':'/users/cbologa/kit/felis','np':4}
    seen=[]
    def fake(cmd,**kw):seen.append(cmd);return '123456;cluster\n'
    monkeypatch.setattr(wf,'run_command',fake)
    job=wf.submission(root,c,'finalize','general','04:00:00',
                      extra=['--dependency','afterok:101:102'],exclude='easley061')
    cmd=seen[0]
    assert job=='123456' and cmd[cmd.index('--dependency')+1]=='afterok:101:102'
    assert cmd[cmd.index('--exclude')+1]=='easley061'
    assert '--gpus' not in cmd and cmd[-7:]==[str(root),'finalize','felis',c['conda_sh'],c['felis_repo'],'4','-']

def test_resume_submits_only_incomplete_groups_and_replaces_pending_finalizer(tmp_path,monkeypatch):
    root=tmp_path/'run';root.mkdir()
    (root/'jobs.tsv').write_text('array\tA\t101\narray\tB\t102\nfinalize\t-\t103\n')
    c={'felis_env':'felis','conda_sh':'/conda.sh','felis_repo':'/felis','np':4}
    m=manifest(root/'work');seen=[]
    monkeypatch.setattr(wf,'read_run',lambda root:(c,m))
    monkeypatch.setattr(wf,'check_prepared',lambda *args:None)
    monkeypatch.setattr(wf,'iteration_status',lambda m,leg,u:{'complete':u['stem']!='b1'})
    def command(cmd,**kw):
        seen.append(cmd)
        if cmd[0]=='squeue':return '103|PENDING\n'
        if cmd[0]=='scancel':return ''
        return str(200+len([x for x in seen if x[0]=='sbatch']))+'\n'
    monkeypatch.setattr(wf,'run_command',command)
    a=argparse.Namespace(run=root,resume=True,partition='l40s',time='24:00:00',concurrency=2,
                         analysis_partition='general',exclude='easley061')
    wf.submit_abfe(a)
    assert ['scancel','103'] in seen
    submits=[x for x in seen if x[0]=='sbatch'];assert len(submits)==2
    assert submits[0][submits[0].index('--array')+1]=='1%2'
    assert all(cmd[cmd.index('--exclude')+1]=='easley061' for cmd in submits)
    assert submits[0][-1]=='B'
    assert submits[1][submits[1].index('--dependency')+1]=='afterok:201'

def test_resume_refuses_to_inspect_or_cancel_running_arrays(tmp_path,monkeypatch):
    root=tmp_path/'run';root.mkdir();(root/'jobs.tsv').write_text('array\tA\t101\nfinalize\t-\t103\n')
    monkeypatch.setattr(wf,'read_run',lambda root:({},manifest(root/'work')))
    monkeypatch.setattr(wf,'check_prepared',lambda *args:None)
    seen=[]
    def command(cmd,**kw):seen.append(cmd);return '101_0|RUNNING\n103|PENDING\n'
    monkeypatch.setattr(wf,'run_command',command)
    def unexpected(*args):raise AssertionError('Read while simulation is active')
    monkeypatch.setattr(wf,'iteration_status',unexpected)
    a=argparse.Namespace(run=root,resume=True)
    with pytest.raises(ValueError,match='still RUNNING'):wf.submit_abfe(a)
    assert len(seen)==1 and seen[0][0]=='squeue'

def test_prep_adapter_keeps_allocated_uuid_and_never_controls_global_mps(monkeypatch):
    from felis_stage import install_adapter
    seen=[]
    class Context:
        def _run_one_subprocess(self,args,working_dir,extra_envs=None):
            seen.append((args,working_dir,extra_envs));return 7
    utils=types.SimpleNamespace();cuda=types.SimpleNamespace()
    install_adapter(Context,utils,cuda)
    monkeypatch.setenv('SAGE_MPS_MANAGED','1')
    monkeypatch.setenv('CUDA_VISIBLE_DEVICES','GPU-00000000-0000-0000-0000-000000000002')
    monkeypatch.setenv('CUDA_MPS_PIPE_DIRECTORY','/tmp/this_job_only/pipe')
    assert utils.get_visible_cuda_devices()==['0']
    c=Context()
    assert c._run_one_subprocess('echo quit | nvidia-cuda-mps-control','/work')==0
    assert c._run_one_subprocess(['nvidia-cuda-mps-control','-d'],'/work')==0
    dynamics=['python3','-m','felis.app.dyn.repex','--tkv','s:filename.stem:sysB_boresch_npt']
    command=c.build_cuda_mps_mpirun_command(dynamics,0,np=4)
    assert command[-len(dynamics):]==dynamics
    assert 'NP_VALUE=4' in command and 'CUDA_VISIBLE_DEVICES' in command
    assert 'CUDA_MPS_PIPE_DIRECTORY' in command and 'bash' not in command
    assert c._run_one_subprocess(command,'/work')==7 and len(seen)==1
    monkeypatch.setenv('CUDA_VISIBLE_DEVICES','')
    assert utils.get_visible_cuda_devices()==[]
    with pytest.raises(ValueError,match='allocated-GPU MPS'):
        c.build_cuda_mps_mpirun_command(dynamics,0,np=4)

def test_stage_uses_job_local_gpu_index_under_slurm_cgroups():
    stage=(PACKAGE/'stage.sbatch').read_text()
    assert 'SAGE_GPU_SELECTOR=$CUDA_VISIBLE_DEVICES' in stage
    assert 'SAGE_GPU_SELECTOR=${SLURM_JOB_GPUS:-$CUDA_VISIBLE_DEVICES}' not in stage

def test_stage_keeps_mpi_temporary_files_off_shared_run_storage():
    stage=(PACKAGE/'stage.sbatch').read_text()
    assert 'SLURM_TMPDIR' in stage
    assert 'export TMPDIR=/tmp' in stage
    assert 'export TMPDIR="$SAGE_RUN/' not in stage

def test_provenance_imports_felis_from_recorded_checkout(tmp_path,monkeypatch):
    repo=tmp_path/'felis_checkout';package=repo/'felis';package.mkdir(parents=True)
    (package/'__init__.py').write_text('')
    (package/'configs.py').write_text(
        'class GlobalKeys:\n'
        '    def __init__(self):\n'
        '        self.integrator=type("Integrator",(),{"dt_ps":0.002})()\n'
    )
    fake_openmm=types.ModuleType('openmm');fake_openmm.__version__='test'
    monkeypatch.setitem(sys.modules,'openmm',fake_openmm)
    monkeypatch.setattr(sys,'path',list(sys.path))
    for name in [n for n in sys.modules if n=='felis' or n.startswith('felis.')]:
        monkeypatch.delitem(sys.modules,name,raising=False)
    try:
        result=wf.installed_provenance({'felis_repo':str(repo)})
        assert Path(result['felis_import']).is_relative_to(repo)
    finally:
        for name in [n for n in sys.modules if n=='felis' or n.startswith('felis.')]:
            sys.modules.pop(name,None)

def test_nonzero_bonded_and_exclusion_integrity_after_merging(params,tmp_path):
    """Emulate ByteMol renaming and insertion behind protein atoms and before water."""
    from openmm import app
    root=tmp_path/'run';root.mkdir();shutil.copytree(params,root/'parameters')
    work=root/'work';prep=work/'prepare';prep.mkdir(parents=True)
    itp=(params/f'{STEM}.itp').read_text().replace('S23_','M00_S23_').replace('LIG 3','M00 3')
    (prep/'M00.itp').write_text(itp)
    from sage_common import read_sucralose
    mol,xyz=read_sucralose(params/f'{STEM}.sdf')
    other='''[ atomtypes ]
DUM DUM 6 12.01 0.0 A 0.3 0.1
OW OW 8 15.999 0.0 A 0.315075 0.635968
HW HW 1 1.008 0.0 A 0.0 0.0
'''
    molecules='''[ moleculetype ]
DUM 3
[ atoms ]
1 DUM 1 DUM C1 1 0 12.01
[ moleculetype ]
SOL 2
[ atoms ]
1 OW 1 SOL OW 1 -0.834 15.999
2 HW 1 SOL HW1 1 0.417 1.008
3 HW 1 SOL HW2 1 0.417 1.008
[ settles ]
1 1 0.09572 0.15139
[ exclusions ]
1 2 3
2 1 3
3 1 2
'''
    for leg,offset in [('A',0),('B',1)]:
        top='[ defaults ]\n'+DEFAULTS+'\n'+other+'\n'+itp+'\n'+molecules
        top+='\n[ system ]\nfixture\n[ molecules ]\n'+('DUM 1\n' if offset else '')+'M00 1\nSOL 1\n'
        (prep/f'sys{leg}.top').write_text(top)
        coordinates=([np.array([1.,1.,1.])] if offset else [])+list(xyz/10)+[np.array([4.,4.,4.]),np.array([4.09572,4,4]),np.array([3.976,4.0927,4])]
        names=(['C1'] if offset else [])+[a[4] for a in rows(itp)['atoms']]+['OW','HW1','HW2']
        residues=([(1,'DUM')] if offset else [])+[(1+offset,'LIG')]*42+[(2+offset,'SOL')]*3
        lines=['fixture\n',f'{len(coordinates):5d}\n']
        for i,(v,name,(resid,resname)) in enumerate(zip(coordinates,names,residues),1):
            lines.append(f'{resid:5d}{resname:<5}{name:>5}{i:5d}{v[0]:8.3f}{v[1]:8.3f}{v[2]:8.3f}\n')
        lines.append('8.00000 8.00000 8.00000\n');(prep/f'sys{leg}.gro').write_text(''.join(lines))
        (prep/f'sys{leg}_ab_ligatoms.json').write_text(json.dumps({'ab':{'ligatoms':list(range(offset,42+offset))}}))
    result=wf.validate_prepared_ligand(root,work)
    assert result['A']['particles']==45 and result['B']['particles']==46
    gmx=os.environ.get('SAGE_TEST_GMX')
    if gmx:
        import subprocess
        for leg in 'AB':
            result=subprocess.run([gmx,'grompp','-f',str(PACKAGE/'grompp_check.mdp'),'-c',str(prep/f'sys{leg}.gro'),
                                   '-p',str(prep/f'sys{leg}.top'),'-o',str(prep/f'{leg}.tpr')],cwd=prep,capture_output=True,text=True)
            assert result.returncode==0, result.stdout+'\n'+result.stderr
