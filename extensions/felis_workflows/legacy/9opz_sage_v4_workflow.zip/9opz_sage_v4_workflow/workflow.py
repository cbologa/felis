#!/usr/bin/env python3
"""Build and run a fresh Sage version of the existing 9OPZ sucralose ABFE."""
from __future__ import annotations
import argparse
import copy
import fcntl
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
import yaml
from sage_common import STEM, PREP_STAGES, sha256, verify_hashes, write_json

DEFAULT_SOURCE=Path('/easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1/production/p1')
DEFAULT_RUN=Path('/easley/scratch/users/cbologa/felis/9opz_campaign/runs/sucralose_p1_sage230/production/p1')
DEFAULT_REPO=Path('/users/cbologa/kit/felis')

def run_command(argv, cwd=None, capture=False):
    print('+', ' '.join(map(str,argv)), flush=True)
    return subprocess.run(list(map(str,argv)),cwd=cwd,check=True,text=True,
                          stdout=subprocess.PIPE if capture else None).stdout

def source_path(source,value):
    p=Path(value);return p.resolve() if p.is_absolute() else (source/p).resolve()

def copy_topology(source,destination,include_dirs):
    """Freeze include dependencies, preserving conditional directives."""
    memo={}
    def visit(src,dst):
        src=src.resolve()
        if src in memo:return memo[src]
        memo[src]=dst.resolve();dst.parent.mkdir(parents=True,exist_ok=True)
        output=[]
        for line in src.read_text().splitlines(keepends=True):
            m=re.match(r'\s*#\s*include\s*["<]([^">]+)[">]',line)
            if not m:output.append(line);continue
            include=Path(m[1]);candidates=[src.parent/include]+[p/include for p in include_dirs]
            found=next((p.resolve() for p in candidates if p.is_file()),None)
            if found is None:raise FileNotFoundError(f'Cannot resolve {m[1]} included by {src}; use --include-dir')
            dest=destination.parent/'topology_includes'/(sha256(found)[:12]+'_'+found.name)
            resolved=visit(found,dest)
            output.append(f'#include "{resolved}"\n')
        dst.write_text(''.join(output));return dst.resolve()
    visit(source,destination)

def token_value(argv,key):
    matches=[x.split(':',2)[2] for x in argv if re.match(r'^[a-z]:',x) and x.split(':',2)[1]==key]
    if len(matches)!=1:raise ValueError(f'Expected exactly one token for {key}: {matches}')
    return matches[0]

def clone_manifest(base,source_work,work,sdf,snapshots=None):
    m=copy.deepcopy(base);m['workdir']=str(work)
    m['force_field']='OpenFF Sage 2.3.0 / AshGC'
    for leg,count_key in [('A','na'),('B','nb')]:
        units=m['units'][leg];lams=m[f'sys{leg}_lam'];n=len(lams)
        if [u['idx'] for u in units]!=list(range(m[count_key])):
            raise ValueError(f'{leg} group indices/count are inconsistent')
        edges=set();covered=set()
        for i,u in enumerate(units):
            if u['stem']!=f'{leg.lower()}{i}':raise ValueError('Expected conventional a0/b0 group names')
            ids=u['ilam']
            if len(ids)<2 or ids!=sorted(set(ids)) or any(j<0 or j>=n for j in ids):
                raise ValueError(f'Invalid lambda group: {ids}')
            covered.update(ids);edges.update(zip(ids,ids[1:]))
            argv=u['argv']
            if argv[:4]!=['python3','-m','felis.app.dyn.repex','--cfg']:
                raise ValueError('Unexpected source repex command format')
            if token_value(argv,'filename.stem')!=u['stem']:
                raise ValueError('Manifest stem differs from the actual simulation command')
            replica_tokens=argv[argv.index('--rextkv')+1:]
            if replica_tokens!=[f'i:ab.ilam:{j}' for j in ids]:
                raise ValueError('Manifest lambda indices differ from the actual simulation command')
            if int(token_value(argv,'integrator.nstep_per_snapshot'))!=2500:
                raise ValueError('This workflow expects the original 2500-step reporting interval')
            if token_value(argv,'dir.trj')!='trj':raise ValueError('Unexpected trajectory output directory')
            for j,x in enumerate(argv):
                if x.startswith('s:filename.monomer:'):argv[j]='s:filename.monomer:'+str(sdf)
                elif snapshots is not None and x.startswith('i:integrator.nsnapshots:'):
                    argv[j]=f'i:integrator.nsnapshots:{snapshots}'
                elif str(source_work) in x:
                    argv[j]=x.replace(str(source_work),str(work))
            u['expected_iterations']=int(token_value(argv,'integrator.nsnapshots'))
            u['checkpoint_interval']=int(token_value(argv,'openmm.checkpoint_interval'))
            if u['expected_iterations']<=0 or u['checkpoint_interval']<=0:raise ValueError('Invalid run length')
            # Prevent an inherited absolute TOP/coordinate/config from reading GAFF2.
            for key in ['filename.sys','filename.crd','filename.atom_ids']:
                p=Path(token_value(argv,key));p=p if p.is_absolute() else work/p
                if not p.resolve().is_relative_to(work):raise ValueError(f'External simulation input: {p}')
            configs=argv[argv.index('--cfg')+1:argv.index('--tkv')]
            for c in configs:
                p=Path(c);p=p if p.is_absolute() else work/p
                if not p.resolve().is_relative_to(work):raise ValueError(f'External configuration: {p}')
        if covered!=set(range(n)) or not set(zip(range(n-1),range(1,n))).issubset(edges):
            raise ValueError(f'{leg} groups do not cover every adjacent lambda transition')
    return m

def initialize(a):
    source=a.source_run.resolve();root=a.run.resolve()
    if root.exists():raise FileExistsError(f'Use a new run directory: {root}')
    config_file=source/'abfecfg.yaml';manifest_file=source/'work_units.json'
    cfg=yaml.safe_load(config_file.read_text());base=json.loads(manifest_file.read_text())
    if cfg.get('cofsdfs') or cfg.get('cofitps'):
        raise ValueError('This package targets the sucralose-only baseline; unexpected cofactors')
    inputs={k:source_path(source,cfg[k]) for k in ['progro','protop','sdffile','itpfile']}
    for p in inputs.values():
        if not p.is_file():raise FileNotFoundError(p)
    if not a.felis_repo.is_dir():raise FileNotFoundError(a.felis_repo)
    root.mkdir(parents=True)
    try:
        for d in ['input','provenance','workflow','slurm_logs','work']:(root/d).mkdir()
        # These are chemistry inputs only. No trajectories, checkpoints, analysis
        # results or stage-completion flags are copied into the new calculation.
        shutil.copyfile(inputs['progro'],root/'input/protein.gro')
        include_dirs=[Path(p).resolve() for p in a.include_dir]
        if os.environ.get('GMXLIB'):include_dirs.append(Path(os.environ['GMXLIB']))
        if os.environ.get('CONDA_PREFIX'):include_dirs.append(Path(os.environ['CONDA_PREFIX'])/'share/gromacs/top')
        copy_topology(inputs['protop'],root/'input/protein.top',include_dirs)
        shutil.copyfile(inputs['sdffile'],root/'input/source_sucralose.sdf')
        shutil.copyfile(inputs['itpfile'],root/'provenance/original_gaff2.itp')
        shutil.copyfile(config_file,root/'provenance/original_abfecfg.yaml')
        shutil.copyfile(manifest_file,root/'provenance/original_work_units.json')
        baseline=Path(base['workdir'])/'analysis/sys_abfe.tsv'
        if baseline.is_file():shutil.copyfile(baseline,root/'provenance/original_sys_abfe.tsv')
        package=Path(__file__).resolve().parent
        for p in package.iterdir():
            if p.is_file():shutil.copyfile(p,root/'workflow'/p.name)
        cfg=copy.deepcopy(cfg)
        cfg.pop('tmpdir',None)
        cfg.update(progro=str(root/'input/protein.gro'),protop=str(root/'input/protein.top'),
                   sdffile=str(root/'parameters'/f'{STEM}.sdf'),itpfile=str(root/'parameters'/f'{STEM}.itp'),
                   outdir=str(root/'work'),stages=['all'])
        work=root/'work'/STEM
        manifest=clone_manifest(base,Path(base['workdir']).resolve(),work,Path(cfg['sdffile']),a.snapshots)
        if any(a.np*len(u['ilam'])>48 for v in manifest['units'].values() for u in v):
            raise ValueError('Too many MPI ranks times lambda states; choose a smaller --np')
        for leg,key in [('A','md_sol_nsnapshots'),('B','md_pro_nsnapshots')]:
            ns={u['expected_iterations'] for u in manifest['units'][leg]}
            if len(ns)!=1:raise ValueError('Source uses unequal per-group run lengths')
            cfg[key]=ns.pop()
        checkpoints={u['checkpoint_interval'] for v in manifest['units'].values() for u in v}
        if len(checkpoints)!=1:raise ValueError('Unequal source checkpoint intervals')
        cfg['md_checkpoint_interval']=checkpoints.pop()
        (root/'abfecfg.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
        prep=copy.deepcopy(cfg);prep['stages']=PREP_STAGES
        (root/'abfecfg.prep.yaml').write_text(yaml.safe_dump(prep,sort_keys=False))
        write_json(root/'work_units.json',manifest)
        control={'source_run':str(source),'run':str(root),'workdir':str(work),
                 'felis_repo':str(a.felis_repo.resolve()),'felis_env':a.felis_env,'sage_env':a.sage_env,
                 'conda_sh':str(a.conda_sh.expanduser().resolve()),'np':a.np,
                 'source_config_sha256':sha256(config_file),'source_manifest_sha256':sha256(manifest_file),
                 'source_input_hashes':{k:sha256(v) for k,v in inputs.items()}}
        write_json(root/'workflow.json',control)
        hashed=[*list((root/'input').rglob('*')),*list((root/'workflow').glob('*')),
                root/'workflow.json',root/'work_units.json',root/'abfecfg.yaml',root/'abfecfg.prep.yaml']
        write_json(root/'input_hashes.json',{str(p.relative_to(root)):sha256(p) for p in hashed if p.is_file()})
    except BaseException:
        # Retain partial setup for diagnosis; never erase arbitrary run directories.
        print(f'Incomplete initialization retained at {root}; use a new --run path after resolving the error.',file=sys.stderr)
        raise
    print(f'Created {root}\nA groups={manifest["na"]}; B groups={manifest["nb"]}; no jobs submitted.')
    print('Next: python workflow.py parameterize --run',root)

def read_run(root,check=True):
    root=root.resolve();control=json.loads((root/'workflow.json').read_text())
    if Path(control['run'])!=root:raise ValueError('Run moved: paths are absolute; initialize a new run')
    if check:verify_hashes(root,json.loads((root/'input_hashes.json').read_text()))
    return control,json.loads((root/'work_units.json').read_text())

def parameterize(root):
    control,_=read_run(root)
    run_command(['conda','run','--no-capture-output','-n',control['sage_env'],'python',root/'workflow/felis_sage_ligand.py',
                 '--sdf',root/'input/source_sucralose.sdf','--output-dir',root/'parameters'])

def installed_provenance(control):
    # Interactive submit/status commands must inspect the same FELIS checkout
    # as Slurm's stage wrapper.  A conda-installed ``felis`` can otherwise win
    # import resolution before any jobs are submitted.
    repo=Path(control['felis_repo']).resolve()
    repo_string=str(repo)
    if repo_string in sys.path:sys.path.remove(repo_string)
    sys.path.insert(0,repo_string)
    import importlib.metadata
    import felis
    import openmm
    path=Path(felis.__file__).resolve()
    if not path.is_relative_to(repo):
        raise ValueError(f'Wrong FELIS import: {path}')
    from felis.configs import GlobalKeys
    if abs(GlobalKeys().integrator.dt_ps-.002)>1e-12:raise ValueError('FELIS default timestep changed from 2 fs')
    files=sorted(str(f.relative_to(repo)) for f in (repo/'felis').rglob('*.py'))
    return {'felis_import':str(path),'openmm_version':openmm.__version__,
            'source_hashes':{f:sha256(Path(control['felis_repo'])/f) for f in files}}

def validate_prepared_ligand(root,work):
    from openmm import app
    import openmm
    from validate_sage import load_export,signatures,compare_signatures
    _,reference=load_export(root/'parameters');expected=signatures(reference);counts={}
    for leg in 'AB':
        gro=app.GromacsGroFile(str(work/f'prepare/sys{leg}.gro'))
        top=app.GromacsTopFile(str(work/f'prepare/sys{leg}.top'),periodicBoxVectors=gro.getPeriodicBoxVectors())
        system=top.createSystem(nonbondedMethod=app.PME,nonbondedCutoff=1.*openmm.unit.nanometer,
                                constraints=None,rigidWater=True,removeCMMotion=False)
        ids=json.loads((work/f'prepare/sys{leg}_ab_ligatoms.json').read_text())['ab']['ligatoms']
        if len(ids)!=42 or len(set(ids))!=42:raise ValueError('Wrong alchemical ligand atom selection')
        assembled=signatures(system,ids)
        try:
            compare_signatures(expected,assembled,allow_mass_rounding=True)
        except ValueError as error:
            raise ValueError(f'System {leg}: {error}') from error
        counts[leg]={'particles':system.getNumParticles(),'ligand_indices':ids,'parameters_match_sage':True,
                     'mass_validation':'original tolerance or exact rounding to 4 decimal places',
                     'max_mass_difference_Da':max(abs(x[3]-y[3]) for x,y in zip(expected['particles'],assembled['particles']))}
        del system,top,gro
    return counts

def prepare_step(root):
    from validate_sage import validate
    control,manifest=read_run(root);work=Path(control['workdir'])
    runtime=installed_provenance(control)
    old_runtime=root/'provenance/felis_runtime.json'
    if old_runtime.exists() and json.loads(old_runtime.read_text())!=runtime:raise ValueError('FELIS runtime changed; use a new run')
    write_json(old_runtime,runtime)
    write_json(root/'provenance/sage_validation_in_felis.json',validate(root/'parameters'))
    base=[sys.executable,str(root/'workflow/felis_stage.py'),'--abfecfg',str(root/'abfecfg.prep.yaml'),'--outdir',str(root/'work'),'--stages']
    run_command(base+['makebox'],cwd=root)
    write_json(root/'provenance/prepared_ligand_validation.json',validate_prepared_ligand(root,work))
    gmx=shutil.which('gmx')
    if not gmx:raise FileNotFoundError('gmx is required to validate the complete solvated topologies')
    for leg in 'AB':
        cmd=[gmx,'grompp','-f',str(root/'workflow/grompp_check.mdp'),'-c',str(work/f'prepare/sys{leg}.gro'),
             '-p',str(work/f'prepare/sys{leg}.top'),'-o',str(root/f'provenance/grompp_{leg}.tpr'),
             '-po',str(root/f'provenance/grompp_{leg}.mdp')]
        with (root/f'provenance/grompp_{leg}.log').open('w') as log:
            subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    run_command(base+PREP_STAGES[1:],cwd=root)
    for name in PREP_STAGES:
        if not (work/'progress'/f'{name}.done').is_file():raise ValueError(f'Missing completed prep stage: {name}')
    (work/'trj').mkdir(exist_ok=True)
    for leg in 'AB':write_json(work/f'prepare/sys{leg}_lam.json',{'ab':{'lam_list':manifest[f'sys{leg}_lam']}})
    checked=[*list((root/'parameters').glob('*')),*list((work/'prepare').rglob('*'))]
    write_json(root/'prepared.ok.json',{'runtime':runtime,'hashes':{str(p.relative_to(root)):sha256(p) for p in checked if p.is_file()}})
    print('Sage preparation and A/B ligand parameter validation PASS.',flush=True)

def check_prepared(root,control):
    ready=json.loads((root/'prepared.ok.json').read_text());verify_hashes(root,ready['hashes'])
    if installed_provenance(control)!=ready['runtime']:raise ValueError('FELIS runtime changed since prep')

def iteration_status(manifest,leg,u):
    import numpy as np
    from openmmtools.multistate import MultiStateReporter
    nc=Path(manifest['workdir'])/'trj'/f'{u["stem"]}.nc'
    if not nc.is_file():return {'stem':u['stem'],'complete':False,'reason':'missing trajectory'}
    r=MultiStateReporter(str(nc),open_mode='r',checkpoint_interval=u['checkpoint_interval'])
    try:
        last=r.read_last_iteration(last_checkpoint=False)
        cp=r.read_last_iteration(last_checkpoint=True)
        target=int(r.read_dict('options')['number_of_iterations'])
        states=np.asarray(r.read_replica_thermodynamic_states(iteration=last)).reshape(-1)
        valid=sorted(map(int,states))==list(range(len(u['ilam'])))
        return {'stem':u['stem'],'last_iteration':last,'last_checkpoint':cp,'stored_target':target,
                'expected_target':u['expected_iterations'],'complete':last==target==u['expected_iterations'] and valid}
    finally:r.close()

def array_step(root,leg,idx):
    control,manifest=read_run(root);check_prepared(root,control)
    u=manifest['units'][leg][idx];work=Path(manifest['workdir'])
    if control['np']*len(u['ilam'])>48:raise ValueError('Too many MPI ranks times lambda states')
    with (work/'trj'/f'{u["stem"]}.run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        info=iteration_status(manifest,leg,u)
        print(json.dumps(info),flush=True)
        if info['complete']:return
        if 'stored_target' in info and info['stored_target']!=u['expected_iterations']:
            raise ValueError('Stored run target differs; initialize a new run instead of silently resuming')
        if (work/'trj'/f'{u["stem"]}.nc').exists() and not (work/'trj'/f'{u["stem"]}.create_done').exists():
            raise ValueError('Trajectory exists without its create_done marker; inspect before restarting')
        argv=[sys.executable,*u['argv'][1:]]
        mpi=['mpirun','--oversubscribe','--bind-to','none','-np',str(control['np'])]
        for name in ['NP_VALUE','PATH','PYTHONPATH','CUDA_VISIBLE_DEVICES','CUDA_MPS_PIPE_DIRECTORY','CUDA_MPS_LOG_DIRECTORY']:
            if name in os.environ:mpi+=['-x',name]
        run_command(mpi+argv,cwd=work)
        info=iteration_status(manifest,leg,u)
        print(json.dumps(info),flush=True)
        if not info['complete']:raise ValueError('Simulation returned before reaching its iteration target')

def finalize_step(root):
    control,manifest=read_run(root);check_prepared(root,control)
    reports=[iteration_status(manifest,leg,u) for leg in 'AB' for u in manifest['units'][leg]]
    write_json(root/'provenance/completion_audit.json',reports)
    incomplete=[r for r in reports if not r['complete']]
    if incomplete:raise ValueError(f'ABFE analysis refused: incomplete groups {incomplete}')
    work=Path(manifest['workdir'])
    for leg in 'AB':write_json(work/f'progress/sys{leg}.done',{'n_cuda_devices':manifest['n'+leg.lower()]})
    run_command([sys.executable,root/'workflow/felis_stage.py','--abfecfg',root/'abfecfg.yaml',
                 '--outdir',root/'work','--stages','mbar','summarize'],cwd=root)
    required=['A_fe_table.tsv','B_fe_table.tsv','sys_abfe.tsv']
    for name in required:
        p=work/'analysis'/name
        if not p.is_file() or not p.stat().st_size:raise ValueError(f'Analysis output missing: {p}')
    print((work/'analysis/sys_abfe.tsv').read_text())
    print('Sage ABFE finalization complete. No experimental-affinity assumption was applied.')

def submission(root,control,mode,partition,walltime,extra=(),gpu=False,leg=None,exclude=None):
    cmd=['sbatch','--parsable','--chdir',str(root),'--job-name',f'9opz_sage_{mode}',
         '--partition',partition,'--nodes','1','--ntasks','1','--cpus-per-task','8','--mem','64G',
         '--time',walltime,'--output',str(root/'slurm_logs/%x_%A_%a.out'),
         '--error',str(root/'slurm_logs/%x_%A_%a.err')]
    if gpu:cmd+=['--gpus','1']
    if exclude:cmd+=['--exclude',exclude]
    cmd+=list(extra)
    cmd += [str(root/'workflow/stage.sbatch'),str(root),mode,control['felis_env'],control['conda_sh'],control['felis_repo'],str(control['np']),leg or '-']
    value=run_command(cmd,capture=True).strip();jobid=value.split(';',1)[0]
    if not jobid.isdigit():raise ValueError(f'Unrecognized sbatch result: {value}')
    with (root/'jobs.tsv').open('a') as f:f.write(f'{mode}\t{leg or "-"}\t{jobid}\n')
    print(f'Submitted {mode} {leg or ""}: {jobid}',flush=True)
    return jobid

def submit_prep(a):
    control,_=read_run(a.run)
    if not (a.run/'parameters/validation.json').is_file():raise ValueError('Run parameterize first')
    submission(a.run,control,'prep',a.partition,a.time,gpu=True,exclude=getattr(a,'exclude',None))

def submit_abfe(a):
    control,m=read_run(a.run);check_prepared(a.run,control)
    previous=[]
    if (a.run/'jobs.tsv').exists():
        previous=[line.split('\t') for line in (a.run/'jobs.tsv').read_text().splitlines()]
    if any(row[0]=='array' for row in previous) and not a.resume:
        raise ValueError('Arrays already submitted. Use --resume after they have stopped.')
    selections={leg:[u['idx'] for u in m['units'][leg]] for leg in 'AB'}
    if a.resume:
        # Query the user's queue, so vanished job IDs do not cause squeue errors.
        queue=run_command(['squeue','--me','--noheader','--format=%i|%T'],capture=True)
        active={line.split('|')[0].strip().split('_')[0]:line.split('|')[1].strip()
                for line in queue.splitlines() if '|' in line}
        for mode,leg,jid in previous:
            if jid in active and (mode!='finalize' or active[jid]!='PENDING'):
                raise ValueError(f'Prior {mode} job {jid} is still {active[jid]}; let it finish before --resume')
        # Read trajectories only after every earlier array task has stopped.
        for leg in 'AB':
            selections[leg]=[]
            for u in m['units'][leg]:
                info=iteration_status(m,leg,u)
                if 'stored_target' in info and info['stored_target']!=u['expected_iterations']:
                    raise ValueError(f'{u["stem"]}: stored target differs; inspect before resuming')
                if not info['complete']:selections[leg].append(u['idx'])
        for mode,leg,jid in previous:
            if mode=='finalize' and jid in active:
                # Replace only this run's pending finalizer, whose dependencies
                # reference the old arrays. Never cancel running simulations.
                run_command(['scancel',jid])
    jobs={}
    # Record each successful submission immediately; never hide a partial submission.
    for leg in 'AB':
        if not selections[leg]:
            print(f'{leg}: all groups are already complete; no GPU jobs needed.')
            continue
        indices=','.join(map(str,selections[leg]))
        jobs[leg]=submission(a.run,control,'array',a.partition,a.time,
                             extra=['--array',f'{indices}%{a.concurrency}'],gpu=True,leg=leg,
                             exclude=getattr(a,'exclude',None))
        write_json(a.run/'submission.json',jobs)
    dependency=['--dependency','afterok:'+':'.join(jobs.values())] if jobs else []
    jobs['finalize']=submission(a.run,control,'finalize',a.analysis_partition,'04:00:00',
                               extra=dependency,exclude=getattr(a,'exclude',None))
    write_json(a.run/'submission.json',jobs)

def status(root):
    control,m=read_run(root,check=False)
    print('Run:',root,'\nWork:',m['workdir'])
    if (root/'jobs.tsv').exists():
        print((root/'jobs.tsv').read_text())
        ids=[line.split('\t')[2] for line in (root/'jobs.tsv').read_text().splitlines()]
        run_command(['sacct','-X','-j',','.join(ids),'--format=JobID%20,JobName%24,State%30,ExitCode,Elapsed'])

def main():
    local=Path(__file__).resolve().parent.parent
    default_run=local if (local/'workflow.json').exists() else DEFAULT_RUN
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
    init=sub.add_parser('init');init.add_argument('--run',type=Path,default=DEFAULT_RUN)
    init.add_argument('--source-run',type=Path,default=DEFAULT_SOURCE)
    init.add_argument('--felis-repo',type=Path,default=DEFAULT_REPO)
    init.add_argument('--felis-env',default='felis');init.add_argument('--sage-env',default='felis_sage_params')
    init.add_argument('--conda-sh',type=Path,default=Path.home()/'miniconda3/etc/profile.d/conda.sh')
    init.add_argument('--include-dir',action='append',default=[]);init.add_argument('--snapshots',type=int)
    init.add_argument('--np',type=int,default=4,choices=[1,2,4])
    for name in ['parameterize','submit-prep','prepare-step','submit-abfe','array-step','finalize-step','status','submit-finalize']:
        s=sub.add_parser(name);s.add_argument('--run',type=Path,default=default_run)
        if name in {'submit-prep','submit-abfe'}:
            s.add_argument('--partition',default='l40s');s.add_argument('--time',default='06:00:00' if name=='submit-prep' else '24:00:00')
        if name in {'submit-prep','submit-abfe','submit-finalize'}:
            s.add_argument('--exclude',help='Slurm node list to exclude from submission')
        if name=='submit-abfe':
            s.add_argument('--concurrency',type=int,default=2,help='Per leg: 2 permits at most 4 array GPUs total')
            s.add_argument('--analysis-partition',default='general')
            s.add_argument('--resume',action='store_true',help='After earlier arrays stop: submit only incomplete groups')
        if name=='array-step':s.add_argument('--leg',choices=['A','B'],required=True);s.add_argument('--idx',type=int,required=True)
        if name=='submit-finalize':s.add_argument('--partition',default='general')
    a=p.parse_args();a.run=a.run.resolve()
    if getattr(a,'concurrency',1)<1:raise ValueError('Concurrency must be positive')
    if a.action=='init':initialize(a)
    elif a.action=='parameterize':parameterize(a.run)
    elif a.action=='submit-prep':submit_prep(a)
    elif a.action=='prepare-step':
        with (a.run/'prep.run.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            prepare_step(a.run)
    elif a.action=='submit-abfe':
        with (a.run/'submission.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            submit_abfe(a)
    elif a.action=='array-step':array_step(a.run,a.leg,a.idx)
    elif a.action=='finalize-step':
        with (a.run/'finalize.run.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            finalize_step(a.run)
    elif a.action=='status':status(a.run)
    elif a.action=='submit-finalize':
        c,_=read_run(a.run);submission(a.run,c,'finalize',a.partition,'04:00:00',exclude=a.exclude)

if __name__=='__main__':main()
