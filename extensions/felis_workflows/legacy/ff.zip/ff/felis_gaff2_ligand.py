#!/usr/bin/env python3
"""
felis_gaff2_ligand.py -- produce a Felis-ready ligand SDF/ITP pair
using GAFF/GAFF2 + AM1-BCC through ACPYPE/AmberTools.

This script is intended for preprocessing only. It does not modify Felis.
It creates:

    <out-prefix>.itp
    <out-prefix>.sdf

Typical use:

    conda activate felisff
    python felis_gaff2_ligand.py \
        --sdf /path/to/ejm_31.sdf \
        --charge 0 \
        --out-prefix /path/to/ejm_31_gaff2

Then validate before using in Felis:

    python validate_felis_itp.py \
        --sdf /path/to/ejm_31_gaff2.sdf \
        --itp /path/to/ejm_31_gaff2.itp \
        --charge 0 \
        --ref /path/to/ByteFF_reference.itp

Key design choices:

1. ACPYPE is allowed to write atomtypes either in LIG_GMX.itp or LIG_GMX.top.
   This script always emits one Felis-facing ITP with [ atomtypes ] first,
   followed by the ligand [ moleculetype ] and bonded/nonbonded sections.

2. The ACPYPE [ defaults ] block is checked for AMBER/GAFF conventions:
   combination rule 2, fudgeLJ 0.5, fudgeQQ 5/6. This matches Felis'
   current AMBER-family fixed-charge/LJ assumptions.

3. The output SDF is generated without RDKit parsing ACPYPE's GAFF MOL2.
   RDKit's MOL2 parser expects Corina-style atom typing; GAFF MOL2 atom
   types such as 'ca' may be misread as elements. By default this script
   copies the input SDF after checking that its element order matches the
   final ITP. Optionally, --sdf-source mol2 converts ACPYPE's MOL2 to SDF
   using Open Babel after a manual GAFF-aware element-order check.

4. This script checks element order only. You should still run
   validate_felis_itp.py afterwards, because its bond-graph check is the
   stronger guard against atom-order corruption.
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from rdkit import Chem


Block = Tuple[Optional[str], str]


COMMON_GAFF_ELEMENT_PREFIXES = (
    ("cl", "Cl"),
    ("br", "Br"),
    ("c", "C"),
    ("n", "N"),
    ("o", "O"),
    ("s", "S"),
    ("p", "P"),
    ("h", "H"),
    ("f", "F"),
    ("i", "I"),
)


MASS_TO_ELEMENT = [
    ("H", 0.5, 1.6),
    ("B", 10.0, 11.5),
    ("C", 11.5, 13.5),
    ("N", 13.5, 15.5),
    ("O", 15.5, 17.5),
    ("F", 18.0, 20.5),
    ("P", 30.0, 31.8),
    ("S", 31.8, 33.5),
    ("Cl", 34.0, 37.5),
    ("Br", 78.0, 81.5),
    ("I", 126.0, 128.5),
]


def die(msg: str, code: int = 1) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(code)


def run(cmd: Sequence[str], *, cwd: Optional[Path] = None) -> None:
    print("[run]", " ".join(map(str, cmd)))
    subprocess.run(list(map(str, cmd)), cwd=str(cwd) if cwd else None, check=True)


def run_acpype(sdf: Path, charge: int, atom_type: str, workdir: Path) -> Dict[str, Path]:
    base = "LIG"
    cmd = [
        "acpype",
        "-i", str(sdf.resolve()),
        "-b", base,
        "-c", "bcc",
        "-a", atom_type,
        "-n", str(charge),
        "-o", "gmx",
    ]
    run(cmd, cwd=workdir)

    acpdir = workdir / f"{base}.acpype"
    if not acpdir.is_dir():
        die(f"ACPYPE did not create expected directory: {acpdir}")

    files: Dict[str, Path] = {
        "acpdir": acpdir,
        "itp": acpdir / f"{base}_GMX.itp",
        "top": acpdir / f"{base}_GMX.top",
        "gro": acpdir / f"{base}_GMX.gro",
    }

    mol2_candidates = sorted(acpdir.glob("*.mol2"))
    files["mol2"] = mol2_candidates[0] if mol2_candidates else Path("")

    for key in ("itp", "top"):
        if not files[key].exists():
            die(f"ACPYPE did not produce {files[key]}")

    return files


def read_blocks(path: Path) -> List[Block]:
    """Split a GROMACS .top/.itp into ordered (section_header, raw_text) chunks."""
    chunks: List[Block] = []
    header: Optional[str] = None
    buf: List[str] = []

    with path.open() as handle:
        for line in handle:
            match = re.match(r"\s*\[\s*([^\]]+?)\s*\]", line)
            if match:
                if header is not None or buf:
                    chunks.append((header, "".join(buf)))
                header = match.group(1).strip().lower()
                buf = [line]
            else:
                buf.append(line)

    if header is not None or buf:
        chunks.append((header, "".join(buf)))

    return chunks


def section_text(chunks: Iterable[Block], section: str) -> str:
    section = section.lower()
    return "".join(text for header, text in chunks if header == section)


def assert_amber_defaults(top_path: Path) -> None:
    """Require AMBER/GAFF GROMACS defaults in ACPYPE's top file."""
    in_defaults = False

    with top_path.open() as handle:
        for raw in handle:
            sec_match = re.match(r"\s*\[\s*([^\]]+?)\s*\]", raw)
            if sec_match:
                in_defaults = sec_match.group(1).strip().lower() == "defaults"
                continue

            if not in_defaults:
                continue

            fields = raw.split(";", 1)[0].split()
            if not fields:
                continue
            if len(fields) < 5:
                continue

            try:
                nbfunc = fields[0]
                comb_rule = fields[1]
                gen_pairs = fields[2]
                fudge_lj = float(fields[3])
                fudge_qq = float(fields[4])
            except ValueError as exc:
                die(f"Could not parse [ defaults ] line in {top_path}: {raw.rstrip()} ({exc})")

            if nbfunc != "1":
                die(f"[ defaults ] nbfunc={nbfunc}; expected 1 for LJ+Coulomb GROMACS topology.")
            if comb_rule != "2":
                die(f"[ defaults ] comb-rule={comb_rule}; expected 2 (sigma/epsilon, Lorentz-Berthelot).")
            if gen_pairs.lower() not in {"yes", "no"}:
                die(f"[ defaults ] gen-pairs={gen_pairs}; expected yes/no.")
            if abs(fudge_lj - 0.5) > 1e-3 or abs(fudge_qq - (5.0 / 6.0)) > 1e-3:
                die(
                    "[ defaults ] fudgeLJ/fudgeQQ "
                    f"= {fudge_lj}/{fudge_qq}; expected 0.5 / 0.833333 for AMBER/GAFF."
                )

            print(
                "[check] AMBER/GAFF defaults OK: "
                f"nbfunc={nbfunc} comb-rule={comb_rule} gen-pairs={gen_pairs} "
                f"fudgeLJ={fudge_lj} fudgeQQ={fudge_qq}"
            )
            return

    print(f"WARN: no [ defaults ] data line found in {top_path}; proceeding without defaults check.")


def build_itp(files: Dict[str, Path], out_itp: Path) -> None:
    """Build one Felis-facing ligand ITP containing [atomtypes] + molecule blocks."""
    itp_chunks = read_blocks(files["itp"])
    top_chunks = read_blocks(files["top"])

    # ACPYPE commonly keeps [ atomtypes ] in the ITP; older/variant outputs may
    # put it in the TOP. We always write it to the final ITP exactly once.
    atomtypes_txt = section_text(itp_chunks, "atomtypes")
    if not atomtypes_txt:
        atomtypes_txt = section_text(top_chunks, "atomtypes")

    if not atomtypes_txt:
        die(f"Could not find [ atomtypes ] in {files['itp']} or {files['top']}")

    drop_sections = {"defaults", "atomtypes", "system", "molecules"}
    molecule_txt = "".join(text for header, text in itp_chunks if header not in drop_sections)

    if "[ moleculetype ]" not in molecule_txt:
        die(f"No [ moleculetype ] block found in ACPYPE ITP: {files['itp']}")
    if "[ atoms ]" not in molecule_txt:
        die(f"No [ atoms ] block found in ACPYPE ITP: {files['itp']}")

    out_itp.parent.mkdir(parents=True, exist_ok=True)
    out_itp.write_text(
        "; Felis-ready GAFF/GAFF2 + AM1-BCC ligand topology assembled from ACPYPE\n"
        "; Generated by felis_gaff2_ligand.py\n\n"
        + atomtypes_txt.rstrip()
        + "\n\n"
        + molecule_txt.lstrip("\n")
    )

    print(f"[write] {out_itp}")


def _element_from_mass(mass: float) -> Optional[str]:
    for element, lo, hi in MASS_TO_ELEMENT:
        if lo <= mass <= hi:
            return element
    return None


def _itp_element_seq(itp_path: Path) -> List[str]:
    """Return element sequence in ITP [ atoms ] order."""
    pt = Chem.GetPeriodicTable()
    type_to_element: Dict[str, str] = {}
    atom_elements: List[str] = []
    section: Optional[str] = None

    with itp_path.open() as handle:
        for raw in handle:
            line = raw.split(";", 1)[0].strip()
            sec_match = re.match(r"\[\s*([^\]]+?)\s*\]", line)
            if sec_match:
                section = sec_match.group(1).strip().lower()
                continue
            if not line:
                continue

            fields = line.split()
            if section == "atomtypes" and fields:
                atype = fields[0]
                # ACPYPE atomtypes lines often include atomic number and mass near
                # the beginning, but exact column positions vary slightly.
                element: Optional[str] = None
                for token in fields[1:5]:
                    try:
                        atnum = int(token)
                    except ValueError:
                        continue
                    if 1 <= atnum <= 118:
                        element = pt.GetElementSymbol(atnum)
                        break
                if element is None:
                    for token in fields[1:6]:
                        try:
                            mass = float(token)
                        except ValueError:
                            continue
                        element = _element_from_mass(mass)
                        if element:
                            break
                if element:
                    type_to_element[atype] = element

            elif section == "atoms" and fields and fields[0].isdigit():
                if len(fields) < 2:
                    die(f"Malformed [ atoms ] line in {itp_path}: {raw.rstrip()}")
                atype = fields[1]
                atom_elements.append(type_to_element.get(atype, "?"))

    return atom_elements


def _sdf_element_seq(sdf_path: Path) -> List[str]:
    suppl = Chem.SDMolSupplier(str(sdf_path), removeHs=False, sanitize=False)
    if not suppl or len(suppl) < 1 or suppl[0] is None:
        die(f"RDKit could not read input SDF: {sdf_path}")
    mol = suppl[0]
    return [atom.GetSymbol() for atom in mol.GetAtoms()]


def _gaff_type_to_element(atom_name: str, atom_type: str) -> str:
    atype = atom_type.lower().strip()
    for prefix, element in COMMON_GAFF_ELEMENT_PREFIXES:
        if atype.startswith(prefix):
            return element

    # Fallback: strip digits/special chars from atom name and infer from first
    # one/two letters. This is not meant to validate chemistry; it is only a
    # last-resort element-order check before the stronger validator is run.
    letters = "".join(ch for ch in atom_name if ch.isalpha())
    if not letters:
        return "?"
    if len(letters) >= 2 and letters[:2].capitalize() in {"Cl", "Br"}:
        return letters[:2].capitalize()
    return letters[0].upper()


def _mol2_element_seq(mol2_path: Path) -> List[str]:
    """Return element sequence from a GAFF/AMBER-style MOL2 without RDKit."""
    elements: List[str] = []
    in_atoms = False

    with mol2_path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if line.startswith("@<TRIPOS>ATOM"):
                in_atoms = True
                continue
            if in_atoms and line.startswith("@<TRIPOS>"):
                break
            if not in_atoms or not line:
                continue

            fields = line.split()
            if len(fields) < 6:
                continue
            atom_name = fields[1]
            atom_type = fields[5]
            elements.append(_gaff_type_to_element(atom_name, atom_type))

    if not elements:
        die(f"No MOL2 atoms parsed from {mol2_path}")
    return elements


def assert_same_element_order(left: List[str], right: List[str], left_name: str, right_name: str) -> None:
    if len(left) != len(right):
        die(f"Atom count mismatch: {left_name} has {len(left)} atoms; {right_name} has {len(right)} atoms")

    mismatches = [
        (i + 1, a, b)
        for i, (a, b) in enumerate(zip(left, right))
        if a != b and a != "?" and b != "?"
    ]
    unknowns = [i + 1 for i, (a, b) in enumerate(zip(left, right)) if a == "?" or b == "?"]

    if mismatches:
        preview = "; ".join(f"#{i} {left_name}={a} {right_name}={b}" for i, a, b in mismatches[:10])
        die(f"Element-order mismatch: {preview}")

    if unknowns:
        preview = ", ".join(map(str, unknowns[:20]))
        print(f"WARN: unknown element assignments at atom positions: {preview}")


def build_sdf_from_input(input_sdf: Path, out_sdf: Path, out_itp: Path) -> None:
    sdf_elements = _sdf_element_seq(input_sdf)
    itp_elements = _itp_element_seq(out_itp)
    assert_same_element_order(sdf_elements, itp_elements, "input_sdf", "itp")

    out_sdf.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(input_sdf, out_sdf)
    print(f"[write] {out_sdf} (copied input SDF; element order matches ITP)")


def build_sdf_from_mol2(files: Dict[str, Path], out_sdf: Path, out_itp: Path) -> None:
    mol2_path = files.get("mol2", Path(""))
    if not mol2_path or not mol2_path.exists():
        die("ACPYPE MOL2 not found; cannot build SDF from MOL2")

    mol2_elements = _mol2_element_seq(mol2_path)
    itp_elements = _itp_element_seq(out_itp)
    assert_same_element_order(mol2_elements, itp_elements, "mol2", "itp")

    obabel = shutil.which("obabel")
    if not obabel:
        die("Open Babel 'obabel' executable not found; install openbabel or use --sdf-source input")

    out_sdf.parent.mkdir(parents=True, exist_ok=True)
    run([obabel, str(mol2_path), "-O", str(out_sdf)])
    print(f"[write] {out_sdf} (Open Babel MOL2->SDF; element order matches ITP)")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate Felis-ready GAFF/GAFF2 AM1-BCC ligand SDF+ITP using ACPYPE."
    )
    parser.add_argument("--sdf", required=True, type=Path, help="input ligand SDF with 3D coordinates")
    parser.add_argument("--charge", required=True, type=int, help="formal net charge of the ligand")
    parser.add_argument("--atom-type", default="gaff2", choices=["gaff2", "gaff"], help="ACPYPE/Antechamber atom type")
    parser.add_argument("--out-prefix", required=True, type=Path, help="output prefix, without .sdf/.itp")
    parser.add_argument("--sdf-source", default="input", choices=["input", "mol2"],
                        help="write output SDF by copying input SDF after order check, or by Open Babel conversion from ACPYPE MOL2")
    parser.add_argument("--keep", action="store_true", help="keep ACPYPE temporary working directory")
    args = parser.parse_args()

    input_sdf = args.sdf
    if not input_sdf.exists():
        die(f"input SDF does not exist: {input_sdf}")

    out_prefix = args.out_prefix
    out_itp = out_prefix.with_suffix(".itp")
    out_sdf = out_prefix.with_suffix(".sdf")

    workdir = Path(tempfile.mkdtemp(prefix="felisff_"))
    try:
        files = run_acpype(input_sdf, args.charge, args.atom_type, workdir)
        assert_amber_defaults(files["top"])
        build_itp(files, out_itp)

        if args.sdf_source == "input":
            build_sdf_from_input(input_sdf, out_sdf, out_itp)
        else:
            build_sdf_from_mol2(files, out_sdf, out_itp)

        print("\nNext: validate before wiring into Felis:")
        print(
            f"  python validate_felis_itp.py --sdf {out_sdf} --itp {out_itp} "
            f"--charge {args.charge} \\\n"
            f"      --ref <path>/ligands_itps_joint-25/<lig>.itp   # optional ByteFF cross-check"
        )
    finally:
        if args.keep:
            print(f"[acpype workdir kept] {workdir}")
        else:
            shutil.rmtree(workdir, ignore_errors=True)


if __name__ == "__main__":
    main()
