#!/usr/bin/env python3
"""
validate_felis_itp.py  --  Check that a ligand .itp is Felis-ready.

Reproduces exactly how Felis ingests a ligand topology:
    GromacsGroFile(gro) + GromacsTopFile(top).createSystem(PME, 1nm, HBonds, ...)
and runs the checks that actually matter for an ABFE run:

  HARD (exit 1 on failure):
    * itp loads through OpenMM's GROMACS reader at all
    * atom COUNT matches the SDF
    * atom ORDER (element sequence) matches the SDF   <-- the silent-killer check
    * nonbonded uses sigma/epsilon (comb-rule 2 / AMBER family), not C6/C12
    * explicit [ pairs ] present (OpenMM does not synthesise 1-4 from gen-pairs)
    * every dihedral funct is OpenMM-readable {1,2,3,4,5,9}
  SOFT (warn only):
    * net charge within 1e-3 of an integer (and == --charge if given)
    * vs --ref: bonds/angles/exceptions should match by connectivity;
      torsion-term count is *expected* to differ (different bonded FF)

Usage:
  python validate_felis_itp.py --sdf lig.sdf --itp lig.itp [--ref byteff.itp] [--charge 0]
"""
import argparse, sys, re
import numpy as np
from rdkit import Chem
import openmm.unit as u
from openmm import NonbondedForce, HarmonicBondForce, HarmonicAngleForce, PeriodicTorsionForce
from openmm.app import GromacsGroFile, GromacsTopFile, PME, HBonds

PT = Chem.GetPeriodicTable()
fail = []; warn = []

def sdf_elements(path):
    m = Chem.MolFromMolFile(path, removeHs=False, sanitize=False)
    if m is None: sys.exit("ERROR: RDKit could not read SDF " + path)
    conf = m.GetConformer()
    xyz = np.array([[conf.GetAtomPosition(i).x, conf.GetAtomPosition(i).y,
                     conf.GetAtomPosition(i).z] for i in range(m.GetNumAtoms())])
    # 1-based bond set, matching .itp atom numbering
    bonds = {frozenset((b.GetBeginAtomIdx()+1, b.GetEndAtomIdx()+1)) for b in m.GetBonds()}
    return [a.GetSymbol() for a in m.GetAtoms()], xyz, bonds

def parse_itp(path):
    """Return dict of directive -> list of nonblank/noncomment rows (in order)."""
    blocks, cur = {}, None
    for raw in open(path):
        line = raw.split(";")[0].rstrip()
        if not line.strip(): continue
        m = re.match(r"\s*\[\s*(\S+)\s*\]", line)
        if m:
            cur = m.group(1).lower()
            blocks.setdefault(cur, [])    # NOTE: two [dihedrals] blocks merge here -> fine for funct check
            continue
        if cur: blocks.setdefault(cur, []).append(line.split())
    return blocks

def itp_atom_elements(blocks):
    """Map atomtype name -> element via at.num (preferred) or mass, then read [atoms] in order."""
    el_of_type = {}
    for r in blocks.get("atomtypes", []):
        name = r[0]
        atnum = next((int(x) for x in r[1:4] if x.lstrip("-").isdigit()), None)
        if atnum: el_of_type[name] = PT.GetElementSymbol(atnum)
    out = []
    for r in blocks.get("atoms", []):
        if not r[0].isdigit(): continue
        atype, mass = r[1], (float(r[7]) if len(r) > 7 else None)
        if atype in el_of_type: out.append(el_of_type[atype])
        elif mass is not None:  out.append(PT.GetElementSymbol(int(round(mass / 1.0))) if mass<2 else _by_mass(mass))
        else: out.append("?")
    return out

def _by_mass(m):
    best, bd = "?", 1e9
    for z in range(1, 95):
        d = abs(PT.GetAtomicWeight(z) - m)
        if d < bd: bd, best = d, PT.GetElementSymbol(z)
    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sdf", required=True); ap.add_argument("--itp", required=True)
    ap.add_argument("--ref"); ap.add_argument("--charge", type=int, default=None)
    a = ap.parse_args()

    sel, xyz, sdf_bonds = sdf_elements(a.sdf)
    blocks = parse_itp(a.itp)

    # --- bond-graph consistency: itp [bonds] pairs must be real SDF bonds (catches same-element swaps) ---
    itp_bonds = {frozenset((int(r[0]), int(r[1]))) for r in blocks.get("bonds", [])
                 if len(r) >= 2 and r[0].isdigit() and r[1].isdigit()}
    if itp_bonds and itp_bonds != sdf_bonds:
        only_itp = list(itp_bonds - sdf_bonds)[:5]
        only_sdf = list(sdf_bonds - itp_bonds)[:5]
        fail.append(f"bond graph mismatch sdf vs itp (atom order inconsistent?): "
                    f"itp-only={[tuple(sorted(x)) for x in only_itp]} "
                    f"sdf-only={[tuple(sorted(x)) for x in only_sdf]}")

    # --- comb-rule sanity: atomtypes must carry sigma/epsilon (7-col), not C6/C12 ---
    if not blocks.get("atomtypes"):
        warn.append("itp has no [ atomtypes ] block (Felis prefixes/prepends types; "
                    "acpype keeps them in the .top -- merge them into the itp).")
    # --- explicit 1-4 pairs ---
    if not blocks.get("pairs"):
        fail.append("no explicit [ pairs ] -- OpenMM's reader will not generate 1-4 from gen-pairs.")
    # --- dihedral functs readable by OpenMM (catches both out-of-range and non-numeric) ---
    OK_FUNCT = {"1", "2", "3", "4", "5", "9"}
    bad = set()
    for r in blocks.get("dihedrals", []):
        if len(r) > 4 and r[0].isdigit():          # a data row: ai aj ak al funct ...
            if r[4] not in OK_FUNCT:
                bad.add(r[4])
    if bad:
        fail.append("dihedral funct(s) not OpenMM-readable: " + ",".join(sorted(bad)))

    # --- atom order vs SDF (the silent killer) ---
    iel = itp_atom_elements(blocks)
    if len(iel) != len(sel):
        fail.append(f"atom COUNT mismatch: sdf={len(sel)} itp={len(iel)}")
    elif iel != sel:
        diffs = [f"#{i+1} sdf={s} itp={t}" for i,(s,t) in enumerate(zip(sel,iel)) if s!=t][:6]
        fail.append("atom ORDER mismatch sdf vs itp: " + "; ".join(diffs))

    # --- build the Felis-style load ---
    nm = xyz / 10.0; n = len(sel)
    molname = blocks["moleculetype"][0][0] if blocks.get("moleculetype") else "MOL"
    with open("_v.gro","w") as g:
        g.write("v\n%5d\n" % n)
        for i in range(n):
            g.write("%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n" % (1,"LIG",sel[i][:5],(i+1)%100000,*nm[i]))
        g.write("%10.5f%10.5f%10.5f\n" % (8,8,8))
    with open("_v.top","w") as t:
        t.write("[ defaults ]\n1 2 yes 0.5 0.83333333\n\n")
        t.write('#include "%s"\n\n[ system ]\nv\n\n[ molecules ]\n%s 1\n' % (a.itp, molname))

    counts = {}
    try:
        gro = GromacsGroFile("_v.gro")
        top = GromacsTopFile("_v.top", periodicBoxVectors=gro.getPeriodicBoxVectors())
        s = top.createSystem(nonbondedMethod=PME, nonbondedCutoff=1.0*u.nanometer,
                             constraints=HBonds, rigidWater=True, ewaldErrorTolerance=5e-4,
                             removeCMMotion=False, hydrogenMass=None, switchDistance=None)
        F = lambda c: next((f for f in s.getForces() if isinstance(f,c)), None)
        nb = F(NonbondedForce)
        q = sum(nb.getParticleParameters(i)[0].value_in_unit(u.elementary_charge) for i in range(s.getNumParticles()))
        counts = dict(particles=s.getNumParticles(), netq=q,
                      bonds=F(HarmonicBondForce).getNumBonds(),
                      angles=F(HarmonicAngleForce).getNumAngles(),
                      torsions=F(PeriodicTorsionForce).getNumTorsions(),
                      exceptions=nb.getNumExceptions())
        if abs(q-round(q)) > 1e-3: warn.append(f"net charge {q:+.4f} not near integer")
        if a.charge is not None and round(q) != a.charge: fail.append(f"net charge {q:+.2f} != requested {a.charge}")
    except Exception as e:
        fail.append("GromacsTopFile.createSystem() FAILED: " + str(e).split("\n")[0])

    print("== candidate ==", counts if counts else "(did not load)")
    if a.ref and counts:
        rb = parse_itp(a.ref)
        with open("_r.top","w") as t:
            t.write("[ defaults ]\n1 2 yes 0.5 0.83333333\n\n")
            rmol = rb["moleculetype"][0][0] if rb.get("moleculetype") else "MOL"
            t.write('#include "%s"\n\n[ system ]\nr\n\n[ molecules ]\n%s 1\n' % (a.ref, rmol))
        rgro = GromacsGroFile("_v.gro")
        rtop = GromacsTopFile("_r.top", periodicBoxVectors=rgro.getPeriodicBoxVectors())
        rs = rtop.createSystem(nonbondedMethod=PME, nonbondedCutoff=1.0*u.nanometer, constraints=HBonds,
                               rigidWater=True, removeCMMotion=False)
        F = lambda c: next((f for f in rs.getForces() if isinstance(f,c)), None)
        ref = dict(particles=rs.getNumParticles(), bonds=F(HarmonicBondForce).getNumBonds(),
                   angles=F(HarmonicAngleForce).getNumAngles(),
                   torsions=F(PeriodicTorsionForce).getNumTorsions(),
                   exceptions=F(NonbondedForce).getNumExceptions())
        print("== reference  ==", ref)
        for k in ("particles","bonds","angles","exceptions"):
            if counts[k] != ref[k]: fail.append(f"{k} differs from ref ({counts[k]} vs {ref[k]}) -- connectivity should match!")
        print(f"   torsion-term delta vs ref: {counts['torsions']-ref['torsions']:+d}  (expected: GAFF2 != ByteFF bonded)")

    print()
    for w in warn: print("WARN:", w)
    for f in fail: print("FAIL:", f)
    print("\nRESULT:", "PASS" if not fail else "FAIL")
    sys.exit(1 if fail else 0)

if __name__ == "__main__": main()
